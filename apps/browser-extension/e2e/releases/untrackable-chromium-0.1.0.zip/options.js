"use strict";
(() => {
  // ../../rules/rules.json
  var rules_default = {
    schemaVersion: 1,
    rules: [
      {
        id: "utm",
        description: "Google Analytics / generic campaign parameters (utm_*)",
        mode: "clean",
        params: [
          "utm_source",
          "utm_medium",
          "utm_campaign",
          "utm_term",
          "utm_content",
          "utm_id",
          "utm_name",
          "utm_cid",
          "utm_reader",
          "utm_referrer",
          "utm_social",
          "utm_social-type",
          "utm_brand",
          "utm_place",
          "utm_pubreferrer",
          "utm_swu",
          "utm_viz_id",
          "utm_source_platform",
          "utm_creative_format",
          "utm_marketing_tactic"
        ],
        prefixes: ["utm_"]
      },
      {
        id: "click-ids",
        description: "Advertising click identifiers (Google, Meta, Microsoft, TikTok, X, Yandex, LinkedIn, Reddit)",
        mode: "clean",
        params: [
          "fbclid",
          "gclid",
          "gclsrc",
          "dclid",
          "gbraid",
          "wbraid",
          "gad_source",
          "gad_campaignid",
          "msclkid",
          "ttclid",
          "twclid",
          "yclid",
          "ysclid",
          "li_fat_id",
          "rdt_cid",
          "epik",
          "srsltid"
        ]
      },
      {
        id: "email-marketing",
        description: "Newsletter and marketing automation identifiers (Mailchimp, HubSpot, Marketo, Vero, Omeda, Openstat)",
        mode: "clean",
        params: [
          "mc_cid",
          "mc_eid",
          "_hsenc",
          "_hsmi",
          "__hssc",
          "__hstc",
          "__hsfp",
          "hsctatracking",
          "mkt_tok",
          "vero_id",
          "vero_conv",
          "oly_anon_id",
          "_openstat",
          "wickedid",
          "rb_clickid",
          "_ga",
          "_gl"
        ]
      },
      {
        id: "share-youtube-spotify",
        description: "Share-sheet identifiers that link a shared URL back to the sharer",
        mode: "clean",
        domains: ["youtube.com", "youtu.be", "spotify.com"],
        params: ["si"]
      },
      {
        id: "share-instagram",
        description: "Instagram share identifiers",
        mode: "clean",
        domains: ["instagram.com"],
        params: ["igsh", "igshid"]
      },
      {
        id: "share-x",
        description: "X / Twitter share tracking",
        mode: "clean",
        domains: ["x.com", "twitter.com"],
        params: ["s", "t"]
      },
      {
        id: "strict-generic",
        description: "Additional referral and analytics parameters (Matomo, Piwik, HubSpot Ads, comScore, Adobe, Branch, AT Internet, Alibaba). Strict mode only because some sites reuse these names functionally.",
        mode: "strict",
        params: [
          "ref",
          "ref_src",
          "ref_url",
          "referrer",
          "spm",
          "scm",
          "trk",
          "trkcampaign",
          "trackingid",
          "cmpid",
          "xtor",
          "ncid",
          "s_kwcid",
          "ef_id",
          "_branch_match_id",
          "_branch_referrer",
          "at_medium",
          "at_campaign",
          "sr_share",
          "igshid",
          "mibextid",
          "pk_campaign",
          "pk_kwd",
          "pk_keyword",
          "pk_source",
          "pk_medium",
          "pk_content",
          "pk_cid",
          "mtm_campaign",
          "mtm_keyword",
          "mtm_source",
          "mtm_medium",
          "mtm_content",
          "mtm_cid",
          "mtm_group",
          "mtm_placement",
          "piwik_campaign",
          "piwik_kwd",
          "hsa_acc",
          "hsa_cam",
          "hsa_grp",
          "hsa_ad",
          "hsa_src",
          "hsa_tgt",
          "hsa_kw",
          "hsa_mt",
          "hsa_net",
          "hsa_ver",
          "itm_source",
          "itm_medium",
          "itm_campaign",
          "itm_content",
          "itm_term",
          "oly_enc_id"
        ],
        prefixes: ["pk_", "mtm_", "piwik_", "hsa_", "itm_", "ns_"]
      },
      {
        id: "strict-amazon",
        description: "Amazon referral, placement and affiliate parameters",
        mode: "strict",
        domains: [
          "amazon.com",
          "amazon.de",
          "amazon.co.uk",
          "amazon.fr",
          "amazon.it",
          "amazon.es",
          "amazon.nl",
          "amazon.ca",
          "amazon.com.au",
          "amazon.co.jp",
          "amazon.in",
          "amazon.pl",
          "amazon.se",
          "amazon.com.be",
          "amazon.at"
        ],
        params: [
          "_encoding",
          "content-id",
          "crid",
          "dib",
          "dib_tag",
          "qid",
          "sprefix",
          "sr",
          "tag",
          "linkcode",
          "linkid",
          "ascsubtag",
          "creative",
          "creativeasin",
          "pf_rd_i",
          "pf_rd_m",
          "pf_rd_p",
          "pf_rd_r",
          "pf_rd_s",
          "pf_rd_t",
          "pd_rd_i",
          "pd_rd_r",
          "pd_rd_w",
          "pd_rd_wg",
          "pd_rd_plhdr"
        ],
        prefixes: ["pf_rd_", "pd_rd_"]
      },
      {
        id: "strict-google-search",
        description: "Google Search telemetry parameters (sa/usg are kept: google.com/url needs them for its redirect)",
        mode: "strict",
        domains: ["google.com", "google.de", "google.co.uk", "google.fr", "google.at", "google.ch"],
        params: [
          "ved",
          "ei",
          "sca_esv",
          "sxsrf",
          "oq",
          "gs_lp",
          "gs_lcrp",
          "sclient",
          "uact",
          "bih",
          "biw",
          "iflsig",
          "rlz",
          "sourceid",
          "aqs"
        ]
      },
      {
        id: "strict-social",
        description: "Facebook, LinkedIn, TikTok and Reddit share parameters",
        mode: "strict",
        domains: ["facebook.com", "linkedin.com", "tiktok.com", "reddit.com"],
        params: [
          "__tn__",
          "__cft__[0]",
          "rdid",
          "refid",
          "lipi",
          "_r",
          "_t",
          "is_from_webapp",
          "sender_device",
          "is_copy_url",
          "share_app_id",
          "share_id"
        ]
      },
      {
        id: "strict-ebay",
        description: "eBay tracking and partner network parameters",
        mode: "strict",
        domains: ["ebay.com", "ebay.de", "ebay.co.uk", "ebay.fr", "ebay.it", "ebay.es", "ebay.at"],
        params: ["_trkparms", "_trksid", "amdata", "mkcid", "mkevt", "mkrid", "campid", "toolid", "customid"]
      },
      {
        id: "strict-aliexpress",
        description: "AliExpress recommendation and affiliate parameters",
        mode: "strict",
        domains: ["aliexpress.com", "aliexpress.us"],
        params: [
          "algo_pvid",
          "algo_exp_id",
          "pdp_npi",
          "pdp_ext_f",
          "gatewayadapt",
          "aff_fcid",
          "aff_fsk",
          "aff_platform",
          "aff_trace_key"
        ],
        prefixes: ["aff_"]
      }
    ],
    protection: {
      description: "A URL matching any of these signals is never modified. Prefer leaving a tracker in place over breaking a login, payment or signed download.",
      domains: [
        "accounts.google.com",
        "pay.google.com",
        "payments.google.com",
        "login.microsoftonline.com",
        "login.microsoft.com",
        "login.live.com",
        "account.live.com",
        "appleid.apple.com",
        "idmsa.apple.com",
        "signin.aws.amazon.com",
        "auth0.com",
        "okta.com",
        "oktapreview.com",
        "onelogin.com",
        "duosecurity.com",
        "login.salesforce.com",
        "id.atlassian.com",
        "login.yahoo.com",
        "paypal.com",
        "checkout.stripe.com",
        "klarna.com",
        "adyen.com",
        "sofort.com",
        "giropay.de",
        "api.github.com"
      ],
      pathKeywords: [
        "oauth",
        "openid",
        "saml",
        "sso",
        "authorize",
        "authorization",
        "authenticate",
        "authentication",
        "auth",
        "callback",
        "login",
        "logon",
        "signin",
        "sign-in",
        "password",
        "passwort",
        "verify",
        "verification",
        "confirm",
        "confirmation",
        "activate",
        "activation",
        "invite",
        "invitation",
        "magic-link",
        "magiclink",
        "unsubscribe",
        "checkout",
        "payment",
        "3ds",
        "token",
        "otp",
        "mfa",
        "2fa",
        "consent",
        "api",
        "checkouts"
      ],
      pathSubstrings: [
        "password",
        "passwort",
        "resetpw",
        "unsubscribe",
        "optout",
        "opt-out",
        "preferencecenter",
        "verifyemail",
        "verify-email",
        "verifyaccount",
        "confirmemail",
        "confirm-email",
        "emailconfirm",
        "emailverif",
        "magiclink",
        "oauth",
        "saml",
        "preferences-center",
        "preference-center",
        "manage-preferences",
        "emailpreferences",
        "email-preferences",
        "subscription-center",
        "subscriptioncenter",
        "manage-subscription",
        "socialsession"
      ],
      params: [
        "sig",
        "signature",
        "hmac",
        "hash",
        "nonce",
        "ticket",
        "session",
        "sessionid",
        "session_id",
        "sid",
        "jsessionid",
        "phpsessid",
        "auth",
        "authkey",
        "apikey",
        "api_key",
        "key-pair-id",
        "otp",
        "password",
        "pwd",
        "passwd",
        "jwt",
        "assertion",
        "client_secret",
        "redirect_uri",
        "response_type",
        "relaystate",
        "sigalg",
        "hdnts",
        "hdntl",
        "auth_code",
        "authcode",
        "verification_code",
        "verify_code",
        "confirmation_code",
        "confirm_code",
        "invite_code",
        "invitation_code",
        "reset_code",
        "otp_code",
        "access_code",
        "activation_code",
        "login_code",
        "security_code",
        "login_hint",
        "id_token_hint",
        "domain_hint"
      ],
      paramPrefixes: ["x-amz-", "x-goog-", "oauth_", "openid.", "saml", "__cf_chl"],
      paramSuffixes: ["token", "signature"],
      paramCombinations: [
        ["code", "state"],
        ["code", "session_state"],
        ["expires", "s"],
        ["exp", "s"],
        ["expires", "h"],
        ["exp", "h"]
      ]
    }
  };

  // ../../packages/core/src/rules.ts
  var EMPTY_PROTECTION = Object.freeze({
    domains: [],
    pathKeywords: [],
    pathSubstrings: [],
    params: [],
    paramPrefixes: [],
    paramSuffixes: [],
    paramCombinations: []
  });
  function rejectUnknownKeys(obj, allowed, where) {
    for (const key of Object.keys(obj)) {
      if (!allowed.includes(key)) throw new Error(`unknown field ${where}.${key}`);
    }
  }
  function isStringArray(value) {
    return Array.isArray(value) && value.every((v) => typeof v === "string");
  }
  function validateRuleSet(value) {
    if (typeof value !== "object" || value === null) throw new Error("rule set must be an object");
    const v = value;
    rejectUnknownKeys(v, ["schemaVersion", "rules", "protection"], "ruleSet");
    if (v.schemaVersion !== 1) throw new Error("unsupported schemaVersion");
    if (!Array.isArray(v.rules)) throw new Error("rules must be an array");
    const ids = /* @__PURE__ */ new Set();
    for (const r of v.rules) {
      if (typeof r !== "object" || r === null) throw new Error("rule must be an object");
      const rule = r;
      rejectUnknownKeys(rule, ["id", "description", "mode", "domains", "params", "prefixes"], "rule");
      if (typeof rule.id !== "string" || rule.id === "") throw new Error("rule.id must be a non-empty string");
      if (typeof rule.description !== "string") throw new Error(`${rule.id}.description must be a string`);
      if (ids.has(rule.id)) throw new Error(`duplicate rule id ${rule.id}`);
      ids.add(rule.id);
      if (rule.mode !== "clean" && rule.mode !== "strict") throw new Error(`invalid mode in ${rule.id}`);
      if (Array.isArray(rule.domains) && rule.domains.length === 0) {
        throw new Error(`${rule.id}.domains must not be empty (omit it for a global rule)`);
      }
      for (const key of ["domains", "params", "prefixes"]) {
        if (rule[key] !== void 0 && !isStringArray(rule[key])) {
          throw new Error(`${rule.id}.${key} must be a string array`);
        }
        if (isStringArray(rule[key]) && rule[key].some((s) => /[A-Z]/.test(s) || s === "")) {
          throw new Error(`${rule.id}.${key} entries must be non-empty lower-case strings`);
        }
      }
    }
    if (v.protection === void 0) v.protection = EMPTY_PROTECTION;
    const p = v.protection;
    if (typeof p !== "object" || p === null || Array.isArray(p)) throw new Error("protection must be an object");
    rejectUnknownKeys(
      p,
      [
        "description",
        "domains",
        "pathKeywords",
        "pathSubstrings",
        "params",
        "paramPrefixes",
        "paramSuffixes",
        "paramCombinations"
      ],
      "protection"
    );
    if (p.description !== void 0 && typeof p.description !== "string") {
      throw new Error("protection.description must be a string");
    }
    for (const key of [
      "domains",
      "pathKeywords",
      "pathSubstrings",
      "params",
      "paramPrefixes",
      "paramSuffixes"
    ]) {
      if (!isStringArray(p[key])) throw new Error(`protection.${key} must be a string array`);
    }
    if (!Array.isArray(p.paramCombinations) || !p.paramCombinations.every(isStringArray)) {
      throw new Error("protection.paramCombinations must be an array of string arrays");
    }
    const lists = [
      ...["domains", "pathKeywords", "pathSubstrings", "params", "paramPrefixes", "paramSuffixes"].map(
        (k) => p[k]
      ),
      ...p.paramCombinations
    ];
    for (const list2 of lists) {
      if (list2.some((s) => s === "" || /[A-Z]/.test(s))) {
        throw new Error("protection entries must be non-empty lower-case strings");
      }
    }
    if (p.paramCombinations.some((c) => c.length === 0)) {
      throw new Error("protection.paramCombinations entries must not be empty");
    }
    return value;
  }
  var defaultRuleSet = validateRuleSet(rules_default);

  // ../../packages/core/src/engine.ts
  function escapeRegExp(s) {
    return s.replace(/[.*+?^${}()|[\]\\/-]/g, "\\$&");
  }
  function asciiLower(s) {
    return s.replace(/[A-Z]/g, (c) => String.fromCharCode(c.charCodeAt(0) + 32));
  }
  function percentDecodeOr(raw) {
    try {
      return decodeURIComponent(raw);
    } catch {
      return raw;
    }
  }
  function normaliseKey(rawKey) {
    const spaced = rawKey.replace(/\+/g, " ");
    return asciiLower(spaced.includes("%") ? percentDecodeOr(spaced) : spaced);
  }
  function domainMatches(host, domain) {
    return host === domain || host.length > domain.length && host.endsWith("." + domain);
  }
  function normaliseException(entry) {
    let e = asciiLower(trimC0(entry));
    if (e.startsWith("*.")) e = e.slice(2);
    if (e === "") return "";
    let host;
    try {
      host = new URL(e.includes("://") ? e : `http://${e}`).hostname;
    } catch {
      return "";
    }
    const h = stripTrailingDots(asciiLower(host));
    return isSaneHost(h) ? h : "";
  }
  function isSaneHost(host) {
    return /^(?:[a-z0-9_.-]+|\[[0-9a-f:.]+\])$/.test(host);
  }
  function stripTrailingDots(host) {
    let h = host;
    while (h.endsWith(".")) h = h.slice(0, -1);
    return h;
  }
  function encodeTrailingWhitespace(url) {
    let end = url.length;
    while (end > 0 && url.charCodeAt(end - 1) <= 32) end--;
    if (end === url.length) return url;
    let tail = "";
    for (let i = end; i < url.length; i++) {
      tail += "%" + url.charCodeAt(i).toString(16).toUpperCase().padStart(2, "0");
    }
    return url.slice(0, end) + tail;
  }
  function trimC0(s) {
    let start = 0;
    let end = s.length;
    while (start < end && s.charCodeAt(start) <= 32) start++;
    while (end > start && s.charCodeAt(end - 1) <= 32) end--;
    return s.slice(start, end);
  }
  function rawKeyOf(segment) {
    const eq = segment.indexOf("=");
    return eq === -1 ? segment : segment.slice(0, eq);
  }
  function isParamShapedFragment(fragment) {
    return fragment.includes("=") && !fragment.includes("/") && !fragment.includes("?") && !fragment.startsWith(":~:");
  }
  var Cleaner = class {
    ruleSet;
    compiled;
    pathKeywordRes;
    protectedParams;
    constructor(ruleSet = defaultRuleSet) {
      this.ruleSet = ruleSet;
      this.compiled = ruleSet.rules.map((rule) => ({
        rule,
        params: new Set(rule.params ?? []),
        prefixes: rule.prefixes ?? [],
        domains: rule.domains
      }));
      this.pathKeywordRes = ruleSet.protection.pathKeywords.map((kw) => ({
        kw,
        re: new RegExp(`(^|[/_.-])(${escapeRegExp(kw)})($|[/_.0-9-])`)
      }));
      this.protectedParams = new Set(ruleSet.protection.params);
    }
    clean(input2, options = {}) {
      const mode = options.mode ?? "clean";
      const unchanged = (status, reason2) => reason2 === void 0 ? { url: input2, changed: false, status, removed: [] } : { url: input2, changed: false, status, removed: [], reason: reason2 };
      if (typeof input2 !== "string") return unchanged("invalid");
      const trimmed = trimC0(input2);
      if (/[\t\n\r]/.test(trimmed)) return unchanged("invalid");
      let parsed;
      try {
        parsed = new URL(trimmed);
      } catch {
        return unchanged("invalid");
      }
      if (parsed.protocol !== "http:" && parsed.protocol !== "https:") return unchanged("unsupported");
      if (!isSaneHost(asciiLower(parsed.hostname))) return unchanged("invalid");
      if (mode === "bypass") return unchanged("bypassed");
      const host = stripTrailingDots(asciiLower(parsed.hostname));
      for (const entry of options.exceptions ?? []) {
        const ex = normaliseException(entry);
        if (ex !== "" && domainMatches(host, ex)) return unchanged("excepted");
      }
      const hashIdx = trimmed.indexOf("#");
      const fragmentStart = hashIdx === -1 ? trimmed.length : hashIdx;
      const qIdx = trimmed.indexOf("?");
      const queryStart = qIdx !== -1 && qIdx < fragmentStart ? qIdx : -1;
      const prefix = trimmed.slice(0, queryStart === -1 ? fragmentStart : queryStart);
      const query = queryStart === -1 ? void 0 : trimmed.slice(queryStart + 1, fragmentStart);
      const fragment = hashIdx === -1 ? void 0 : trimmed.slice(hashIdx + 1);
      const reason = this.protectionReason(host, parsed.pathname, query, fragment);
      if (reason !== void 0) return unchanged("protected", reason);
      const applicable = this.compiled.filter(
        (c) => (c.rule.mode === "clean" || mode === "strict") && (c.domains === void 0 || c.domains.some((d) => domainMatches(host, d)))
      );
      const removed = [];
      const cleanPart = (part, location) => part.split("&").filter((segment) => {
        const rawKey = rawKeyOf(segment);
        const key = normaliseKey(rawKey);
        const match = applicable.find((c) => c.params.has(key) || c.prefixes.some((p) => key.startsWith(p)));
        if (match === void 0) return true;
        removed.push({ name: rawKey, location, ruleId: match.rule.id });
        return false;
      }).join("&");
      const newQuery = query === void 0 ? void 0 : cleanPart(query, "query");
      const removedFromQuery = removed.length;
      const newFragment = fragment !== void 0 && mode === "strict" && isParamShapedFragment(fragment) ? cleanPart(fragment, "fragment") : fragment;
      const removedFromFragment = removed.length - removedFromQuery;
      if (removed.length === 0) return unchanged("unchanged");
      let url = prefix;
      if (newQuery !== void 0 && !(newQuery === "" && removedFromQuery > 0)) url += "?" + newQuery;
      if (newFragment !== void 0 && !(newFragment === "" && removedFromFragment > 0)) url += "#" + newFragment;
      url = encodeTrailingWhitespace(url);
      return { url, changed: url !== input2, status: "cleaned", removed };
    }
    protectionReason(host, pathname, query, fragment) {
      const p = this.ruleSet.protection;
      const domain = p.domains.find((d) => domainMatches(host, d));
      if (domain !== void 0) return `domain:${domain}`;
      const path = asciiLower(percentDecodeOr(pathname));
      const kw = this.pathKeywordRes.find(({ re }) => re.test(path));
      if (kw !== void 0) return `path:${kw.kw}`;
      const sub = p.pathSubstrings.find((x) => path.includes(x));
      if (sub !== void 0) return `path:${sub}`;
      const keys = [];
      if (query !== void 0) for (const seg of query.split("&")) keys.push(normaliseKey(rawKeyOf(seg)));
      if (fragment !== void 0 && fragment.includes("=")) {
        for (const seg of fragment.split("&")) keys.push(normaliseKey(rawKeyOf(seg)));
      }
      for (const key of keys) {
        if (key === "") continue;
        if (this.protectedParams.has(key) || p.paramPrefixes.some((x) => key.startsWith(x)) || p.paramSuffixes.some((x) => key.endsWith(x))) {
          return `param:${key}`;
        }
      }
      const keySet = new Set(keys);
      const combo = p.paramCombinations.find((c) => c.every((k) => keySet.has(k)));
      if (combo !== void 0) return `combination:${combo.join("+")}`;
      return void 0;
    }
  };
  var defaultCleaner = new Cleaner();
  function cleanUrl(input2, options = {}) {
    return defaultCleaner.clean(input2, options);
  }

  // ../../packages/core/src/dnr.ts
  function toAsciiDomain(entry) {
    const host = normaliseException(entry);
    if (host === "") return "";
    try {
      const u = new URL(`http://${host}/`);
      if (u.hostname.startsWith("[")) return "";
      if (u.port !== "" || u.username !== "" || u.pathname !== "/" || asciiLower(u.hostname) !== u.hostname) return "";
      return host;
    } catch {
      return "";
    }
  }

  // src/settings.ts
  var DEFAULT_SETTINGS = Object.freeze({
    enabled: true,
    mode: "clean",
    exceptions: [],
    pausedUntil: 0,
    copyCleaning: true
  });
  var MAX_EXCEPTIONS = 1e3;
  function sanitizeExceptions(entries) {
    const out = /* @__PURE__ */ new Set();
    for (const entry of entries) {
      if (typeof entry !== "string" || entry.length > 2048) continue;
      const domain = toAsciiDomain(entry);
      if (domain !== "" && domain.length <= 253) out.add(domain);
      if (out.size >= MAX_EXCEPTIONS) break;
    }
    return [...out].sort();
  }
  function sanitizeSettings(raw) {
    const r = typeof raw === "object" && raw !== null ? raw : {};
    const pausedUntil = typeof r.pausedUntil === "number" && Number.isFinite(r.pausedUntil) && r.pausedUntil > 0 ? r.pausedUntil : 0;
    return {
      enabled: typeof r.enabled === "boolean" ? r.enabled : DEFAULT_SETTINGS.enabled,
      mode: r.mode === "strict" ? "strict" : "clean",
      exceptions: Array.isArray(r.exceptions) ? sanitizeExceptions(r.exceptions) : [],
      pausedUntil,
      copyCleaning: typeof r.copyCleaning === "boolean" ? r.copyCleaning : DEFAULT_SETTINGS.copyCleaning
    };
  }
  function effectiveMode(s, now = Date.now()) {
    if (!s.enabled || s.pausedUntil > now) return "bypass";
    return s.mode;
  }
  var SETTINGS_KEYS = Object.keys(DEFAULT_SETTINGS);
  async function loadSettings() {
    const stored = await chrome.storage.local.get(SETTINGS_KEYS);
    return sanitizeSettings({ ...DEFAULT_SETTINGS, ...stored });
  }
  async function saveSettings(patch) {
    const next = sanitizeSettings({ ...await loadSettings(), ...patch });
    await chrome.storage.local.set(next);
    return next;
  }

  // src/options.ts
  function $(id) {
    const el = document.getElementById(id);
    if (el === null) throw new Error(`missing #${id}`);
    return el;
  }
  var enabledBox = $("enabled");
  var modeRadios = [...document.querySelectorAll('input[name="mode"]')];
  var copyBox = $("copy-cleaning");
  var loopBox = $("loop-recovery");
  var LOOP_PERMISSION = { permissions: ["webNavigation"] };
  var pauseStatus = $("pause-status");
  var form = $("add-exception");
  var input = $("exception-input");
  var errorEl = $("exception-error");
  var list = $("exceptions");
  var empty = $("no-exceptions");
  var previewInput = $("preview-input");
  var previewOutput = $("preview-output");
  var openUnmodifiedBtn = $("open-unmodified");
  var current;
  function render(s) {
    current = s;
    enabledBox.checked = s.enabled;
    for (const r of modeRadios) r.checked = r.value === s.mode;
    copyBox.checked = s.copyCleaning;
    pauseStatus.textContent = s.enabled && s.pausedUntil > Date.now() ? `Paused until ${new Date(s.pausedUntil).toLocaleTimeString()}.` : "";
    list.replaceChildren(
      ...s.exceptions.map((domain) => {
        const li = document.createElement("li");
        const code = document.createElement("code");
        code.textContent = domain;
        const btn = document.createElement("button");
        btn.type = "button";
        btn.textContent = "Remove";
        btn.setAttribute("aria-label", `Remove exception ${domain}`);
        btn.addEventListener("click", async () => {
          const latest = await loadSettings();
          await saveSettings({ exceptions: latest.exceptions.filter((d) => d !== domain) });
        });
        li.append(code, btn);
        return li;
      })
    );
    empty.hidden = s.exceptions.length > 0;
    renderPreview();
  }
  function renderPreview() {
    const value = previewInput.value;
    previewOutput.replaceChildren();
    openUnmodifiedBtn.disabled = true;
    if (value.trim() === "" || current === void 0) return;
    const mode = effectiveMode(current);
    const result = cleanUrl(value, { mode, exceptions: current.exceptions });
    openUnmodifiedBtn.disabled = result.status === "invalid" || result.status === "unsupported";
    const p = document.createElement("p");
    const messages = {
      cleaned: "Cleaned link:",
      unchanged: "No tracking parameters found.",
      protected: "Left unchanged: this looks like a sign-in, payment or signed link",
      bypassed: "Cleaning is currently off or paused.",
      excepted: "Left unchanged: this site is in your exceptions.",
      unsupported: "Only http and https links are cleaned.",
      invalid: "This is not a valid link."
    };
    p.textContent = messages[result.status] + (result.reason ? ` (${result.reason}).` : "");
    previewOutput.append(p);
    if (result.status === "cleaned") {
      const code = document.createElement("code");
      code.textContent = result.url;
      const ul = document.createElement("ul");
      for (const r of result.removed) {
        const li = document.createElement("li");
        li.textContent = `${r.name} (${r.location}, rule \u201C${r.ruleId}\u201D)`;
        ul.append(li);
      }
      previewOutput.append(code, ul);
    }
  }
  enabledBox.addEventListener("change", () => void saveSettings({ enabled: enabledBox.checked, pausedUntil: 0 }));
  for (const r of modeRadios) {
    r.addEventListener("change", () => {
      if (r.checked) void saveSettings({ mode: r.value === "strict" ? "strict" : "clean" });
    });
  }
  copyBox.addEventListener("change", () => void saveSettings({ copyCleaning: copyBox.checked }));
  void chrome.permissions.contains(LOOP_PERMISSION).then((granted) => loopBox.checked = granted);
  loopBox.addEventListener("change", () => {
    const op = loopBox.checked ? chrome.permissions.request(LOOP_PERMISSION) : chrome.permissions.remove(LOOP_PERMISSION);
    void op.then(() => chrome.permissions.contains(LOOP_PERMISSION)).then((granted) => loopBox.checked = granted).catch(() => loopBox.checked = false);
  });
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    void (async () => {
      const domain = toAsciiDomain(input.value);
      const s = await loadSettings();
      if (domain === "") {
        errorEl.textContent = "Please enter a domain such as example.com.";
        return;
      }
      if (s.exceptions.length >= MAX_EXCEPTIONS) {
        errorEl.textContent = `At most ${MAX_EXCEPTIONS} exceptions are supported.`;
        return;
      }
      errorEl.textContent = "";
      input.value = "";
      await saveSettings({ exceptions: [...s.exceptions, domain] });
    })();
  });
  previewInput.addEventListener("input", renderPreview);
  openUnmodifiedBtn.addEventListener("click", () => {
    void chrome.runtime.sendMessage({ type: "openUnmodified", url: previewInput.value.trim() });
  });
  chrome.storage.onChanged.addListener((_c, area) => {
    if (area === "local") void loadSettings().then(render);
  });
  void loadSettings().then(render);
})();
