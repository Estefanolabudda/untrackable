"use strict";
(() => {
  // src/content.ts
  var SINGLE_URL = /^https?:\/\/\S+$/i;
  var MAX_LENGTH = 8192;
  var GESTURE_WINDOW_MS = 1e3;
  var gestureAt = -Infinity;
  function isCopyKeystroke(e) {
    const key = e.key.toLowerCase();
    const c = e.code === "KeyC" || key === "c";
    return (e.ctrlKey || e.metaKey) && c || e.ctrlKey && (e.code === "Insert" || key === "insert");
  }
  function onKeyDown(e) {
    if (e.isTrusted && isCopyKeystroke(e)) gestureAt = performance.now();
  }
  function consumeGesture() {
    const ok = performance.now() - gestureAt <= GESTURE_WINDOW_MS;
    gestureAt = -Infinity;
    return ok;
  }
  function selectedText() {
    const active = document.activeElement;
    if (active instanceof HTMLInputElement || active instanceof HTMLTextAreaElement) {
      const { selectionStart, selectionEnd, value } = active;
      if (selectionStart !== null && selectionEnd !== null && selectionEnd > selectionStart) {
        return value.slice(selectionStart, selectionEnd);
      }
    }
    return window.getSelection()?.toString() ?? "";
  }
  function extensionAlive() {
    try {
      return chrome.runtime?.id !== void 0;
    } catch {
      return false;
    }
  }
  function detach() {
    window.removeEventListener("keydown", onKeyDown, true);
    document.removeEventListener("copy", onCopy, true);
  }
  function onCopy(event) {
    if (!extensionAlive()) {
      detach();
      return;
    }
    if (!event.isTrusted || !consumeGesture()) return;
    const text = selectedText().trim();
    const link = text.length <= MAX_LENGTH && SINGLE_URL.test(text) ? text : void 0;
    setTimeout(() => {
      if (!extensionAlive()) return;
      const url = event.defaultPrevented ? void 0 : link;
      chrome.runtime.sendMessage(url === void 0 ? { type: "copied" } : { type: "copied", url }).catch(() => {
      });
    }, 0);
  }
  window.addEventListener("keydown", onKeyDown, true);
  document.addEventListener("copy", onCopy, true);
})();
