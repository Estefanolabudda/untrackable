"use strict";
(() => {
  // ../../rules/rules.json
  var rules_default = {
    schemaVersion: 1,
    rules: [
      {
        id: "utm",
        description: "Google Analytics / generic campaign parameters (utm_*)",
        mode: "clean",
        params: [
          "utm_source",
          "utm_medium",
          "utm_campaign",
          "utm_term",
          "utm_content",
          "utm_id",
          "utm_name",
          "utm_cid",
          "utm_reader",
          "utm_referrer",
          "utm_social",
          "utm_social-type",
          "utm_brand",
          "utm_place",
          "utm_pubreferrer",
          "utm_swu",
          "utm_viz_id",
          "utm_source_platform",
          "utm_creative_format",
          "utm_marketing_tactic"
        ],
        prefixes: ["utm_"]
      },
      {
        id: "click-ids",
        description: "Advertising click identifiers (Google, Meta, Microsoft, TikTok, X, Yandex, LinkedIn, Reddit)",
        mode: "clean",
        params: [
          "fbclid",
          "gclid",
          "gclsrc",
          "dclid",
          "gbraid",
          "wbraid",
          "gad_source",
          "gad_campaignid",
          "msclkid",
          "ttclid",
          "twclid",
          "yclid",
          "ysclid",
          "li_fat_id",
          "rdt_cid",
          "epik",
          "srsltid"
        ]
      },
      {
        id: "email-marketing",
        description: "Newsletter and marketing automation identifiers (Mailchimp, HubSpot, Marketo, Vero, Omeda, Openstat)",
        mode: "clean",
        params: [
          "mc_cid",
          "mc_eid",
          "_hsenc",
          "_hsmi",
          "__hssc",
          "__hstc",
          "__hsfp",
          "hsctatracking",
          "mkt_tok",
          "vero_id",
          "vero_conv",
          "oly_anon_id",
          "_openstat",
          "wickedid",
          "rb_clickid",
          "_ga",
          "_gl"
        ]
      },
      {
        id: "share-youtube-spotify",
        description: "Share-sheet identifiers that link a shared URL back to the sharer",
        mode: "clean",
        domains: ["youtube.com", "youtu.be", "spotify.com"],
        params: ["si"]
      },
      {
        id: "share-instagram",
        description: "Instagram share identifiers",
        mode: "clean",
        domains: ["instagram.com"],
        params: ["igsh", "igshid"]
      },
      {
        id: "share-x",
        description: "X / Twitter share tracking",
        mode: "clean",
        domains: ["x.com", "twitter.com"],
        params: ["s", "t"]
      },
      {
        id: "strict-generic",
        description: "Additional referral and analytics parameters (Matomo, Piwik, HubSpot Ads, comScore, Adobe, Branch, AT Internet, Alibaba). Strict mode only because some sites reuse these names functionally.",
        mode: "strict",
        params: [
          "ref",
          "ref_src",
          "ref_url",
          "referrer",
          "spm",
          "scm",
          "trk",
          "trkcampaign",
          "trackingid",
          "cmpid",
          "xtor",
          "ncid",
          "s_kwcid",
          "ef_id",
          "_branch_match_id",
          "_branch_referrer",
          "at_medium",
          "at_campaign",
          "sr_share",
          "igshid",
          "mibextid",
          "pk_campaign",
          "pk_kwd",
          "pk_keyword",
          "pk_source",
          "pk_medium",
          "pk_content",
          "pk_cid",
          "mtm_campaign",
          "mtm_keyword",
          "mtm_source",
          "mtm_medium",
          "mtm_content",
          "mtm_cid",
          "mtm_group",
          "mtm_placement",
          "piwik_campaign",
          "piwik_kwd",
          "hsa_acc",
          "hsa_cam",
          "hsa_grp",
          "hsa_ad",
          "hsa_src",
          "hsa_tgt",
          "hsa_kw",
          "hsa_mt",
          "hsa_net",
          "hsa_ver",
          "itm_source",
          "itm_medium",
          "itm_campaign",
          "itm_content",
          "itm_term",
          "oly_enc_id"
        ],
        prefixes: ["pk_", "mtm_", "piwik_", "hsa_", "itm_", "ns_"]
      },
      {
        id: "strict-amazon",
        description: "Amazon referral, placement and affiliate parameters",
        mode: "strict",
        domains: [
          "amazon.com",
          "amazon.de",
          "amazon.co.uk",
          "amazon.fr",
          "amazon.it",
          "amazon.es",
          "amazon.nl",
          "amazon.ca",
          "amazon.com.au",
          "amazon.co.jp",
          "amazon.in",
          "amazon.pl",
          "amazon.se",
          "amazon.com.be",
          "amazon.at"
        ],
        params: [
          "_encoding",
          "content-id",
          "crid",
          "dib",
          "dib_tag",
          "qid",
          "sprefix",
          "sr",
          "tag",
          "linkcode",
          "linkid",
          "ascsubtag",
          "creative",
          "creativeasin",
          "pf_rd_i",
          "pf_rd_m",
          "pf_rd_p",
          "pf_rd_r",
          "pf_rd_s",
          "pf_rd_t",
          "pd_rd_i",
          "pd_rd_r",
          "pd_rd_w",
          "pd_rd_wg",
          "pd_rd_plhdr"
        ],
        prefixes: ["pf_rd_", "pd_rd_"]
      },
      {
        id: "strict-google-search",
        description: "Google Search telemetry parameters (sa/usg are kept: google.com/url needs them for its redirect)",
        mode: "strict",
        domains: ["google.com", "google.de", "google.co.uk", "google.fr", "google.at", "google.ch"],
        params: [
          "ved",
          "ei",
          "sca_esv",
          "sxsrf",
          "oq",
          "gs_lp",
          "gs_lcrp",
          "sclient",
          "uact",
          "bih",
          "biw",
          "iflsig",
          "rlz",
          "sourceid",
          "aqs"
        ]
      },
      {
        id: "strict-social",
        description: "Facebook, LinkedIn, TikTok and Reddit share parameters",
        mode: "strict",
        domains: ["facebook.com", "linkedin.com", "tiktok.com", "reddit.com"],
        params: [
          "__tn__",
          "__cft__[0]",
          "rdid",
          "refid",
          "lipi",
          "_r",
          "_t",
          "is_from_webapp",
          "sender_device",
          "is_copy_url",
          "share_app_id",
          "share_id"
        ]
      },
      {
        id: "strict-ebay",
        description: "eBay tracking and partner network parameters",
        mode: "strict",
        domains: ["ebay.com", "ebay.de", "ebay.co.uk", "ebay.fr", "ebay.it", "ebay.es", "ebay.at"],
        params: ["_trkparms", "_trksid", "amdata", "mkcid", "mkevt", "mkrid", "campid", "toolid", "customid"]
      },
      {
        id: "strict-aliexpress",
        description: "AliExpress recommendation and affiliate parameters",
        mode: "strict",
        domains: ["aliexpress.com", "aliexpress.us"],
        params: [
          "algo_pvid",
          "algo_exp_id",
          "pdp_npi",
          "pdp_ext_f",
          "gatewayadapt",
          "aff_fcid",
          "aff_fsk",
          "aff_platform",
          "aff_trace_key"
        ],
        prefixes: ["aff_"]
      }
    ],
    protection: {
      description: "A URL matching any of these signals is never modified. Prefer leaving a tracker in place over breaking a login, payment or signed download.",
      domains: [
        "accounts.google.com",
        "pay.google.com",
        "payments.google.com",
        "login.microsoftonline.com",
        "login.microsoft.com",
        "login.live.com",
        "account.live.com",
        "appleid.apple.com",
        "idmsa.apple.com",
        "signin.aws.amazon.com",
        "auth0.com",
        "okta.com",
        "oktapreview.com",
        "onelogin.com",
        "duosecurity.com",
        "login.salesforce.com",
        "id.atlassian.com",
        "login.yahoo.com",
        "paypal.com",
        "checkout.stripe.com",
        "klarna.com",
        "adyen.com",
        "sofort.com",
        "giropay.de",
        "api.github.com"
      ],
      pathKeywords: [
        "oauth",
        "openid",
        "saml",
        "sso",
        "authorize",
        "authorization",
        "authenticate",
        "authentication",
        "auth",
        "callback",
        "login",
        "logon",
        "signin",
        "sign-in",
        "password",
        "passwort",
        "verify",
        "verification",
        "confirm",
        "confirmation",
        "activate",
        "activation",
        "invite",
        "invitation",
        "magic-link",
        "magiclink",
        "unsubscribe",
        "checkout",
        "payment",
        "3ds",
        "token",
        "otp",
        "mfa",
        "2fa",
        "consent",
        "api",
        "checkouts"
      ],
      pathSubstrings: [
        "password",
        "passwort",
        "resetpw",
        "unsubscribe",
        "optout",
        "opt-out",
        "preferencecenter",
        "verifyemail",
        "verify-email",
        "verifyaccount",
        "confirmemail",
        "confirm-email",
        "emailconfirm",
        "emailverif",
        "magiclink",
        "oauth",
        "saml",
        "preferences-center",
        "preference-center",
        "manage-preferences",
        "emailpreferences",
        "email-preferences",
        "subscription-center",
        "subscriptioncenter",
        "manage-subscription",
        "socialsession"
      ],
      params: [
        "sig",
        "signature",
        "hmac",
        "hash",
        "nonce",
        "ticket",
        "session",
        "sessionid",
        "session_id",
        "sid",
        "jsessionid",
        "phpsessid",
        "auth",
        "authkey",
        "apikey",
        "api_key",
        "key-pair-id",
        "otp",
        "password",
        "pwd",
        "passwd",
        "jwt",
        "assertion",
        "client_secret",
        "redirect_uri",
        "response_type",
        "relaystate",
        "sigalg",
        "hdnts",
        "hdntl",
        "auth_code",
        "authcode",
        "verification_code",
        "verify_code",
        "confirmation_code",
        "confirm_code",
        "invite_code",
        "invitation_code",
        "reset_code",
        "otp_code",
        "access_code",
        "activation_code",
        "login_code",
        "security_code",
        "login_hint",
        "id_token_hint",
        "domain_hint",
        "hdnea",
        "sesskey",
        "logouthash"
      ],
      paramPrefixes: ["x-amz-", "x-goog-", "oauth_", "openid.", "saml", "__cf_chl"],
      paramSuffixes: ["token", "signature"],
      paramCombinations: [
        ["code", "state"],
        ["code", "session_state"],
        ["expires", "s"],
        ["exp", "s"],
        ["expires", "h"],
        ["exp", "h"],
        ["ex", "hm"],
        ["oh", "oe"],
        ["len", "data"],
        ["st", "e"]
      ],
      experimentalParams: [
        "code",
        "error",
        "csrf",
        "_csrf",
        "xsrf",
        "_xsrf",
        "payment_intent",
        "payment_intent_client_secret",
        "setup_intent",
        "setup_intent_client_secret",
        "redirect_status",
        "paymentid",
        "payment_id",
        "payerid",
        "pares",
        "cres",
        "redirectresult",
        "expires",
        "key",
        "return_to",
        "returnto",
        "return_url",
        "returnurl",
        "redirect_url",
        "redirect_to",
        "callback_url",
        "tctokenurl",
        "wa",
        "wtrealm",
        "wctx",
        "wresult",
        "__token__",
        "rlkey",
        "resourcekey",
        "oobcode",
        "token_hash",
        "__clerk_ticket",
        "__clerk_status",
        "user_code",
        "device_code",
        "_wpnonce",
        "wmsauthsign",
        "auth_key",
        "trxid",
        "trxref",
        "shasign",
        "seal",
        "resourcepath",
        "merchantsig",
        "authorization",
        "redirect_flow_id",
        "amazoncheckoutsessionid",
        "orderkey",
        "mac2",
        "resultcode",
        "verify",
        "confirm",
        "invite",
        "inviteid"
      ]
    }
  };

  // ../../packages/core/src/rules.ts
  var EMPTY_PROTECTION = Object.freeze({
    domains: [],
    pathKeywords: [],
    pathSubstrings: [],
    params: [],
    paramPrefixes: [],
    paramSuffixes: [],
    paramCombinations: []
  });
  function rejectUnknownKeys(obj, allowed, where) {
    for (const key of Object.keys(obj)) {
      if (!allowed.includes(key)) throw new Error(`unknown field ${where}.${key}`);
    }
  }
  function isStringArray(value) {
    return Array.isArray(value) && value.every((v) => typeof v === "string");
  }
  function validateRuleSet(value) {
    if (typeof value !== "object" || value === null) throw new Error("rule set must be an object");
    const v = value;
    rejectUnknownKeys(v, ["schemaVersion", "rules", "protection"], "ruleSet");
    if (v.schemaVersion !== 1) throw new Error("unsupported schemaVersion");
    if (!Array.isArray(v.rules)) throw new Error("rules must be an array");
    const ids = /* @__PURE__ */ new Set();
    for (const r of v.rules) {
      if (typeof r !== "object" || r === null) throw new Error("rule must be an object");
      const rule = r;
      rejectUnknownKeys(rule, ["id", "description", "mode", "domains", "params", "prefixes"], "rule");
      if (typeof rule.id !== "string" || rule.id === "") throw new Error("rule.id must be a non-empty string");
      if (typeof rule.description !== "string") throw new Error(`${rule.id}.description must be a string`);
      if (ids.has(rule.id)) throw new Error(`duplicate rule id ${rule.id}`);
      ids.add(rule.id);
      if (rule.mode !== "clean" && rule.mode !== "strict") throw new Error(`invalid mode in ${rule.id}`);
      if (Array.isArray(rule.domains) && rule.domains.length === 0) {
        throw new Error(`${rule.id}.domains must not be empty (omit it for a global rule)`);
      }
      for (const key of ["domains", "params", "prefixes"]) {
        if (rule[key] !== void 0 && !isStringArray(rule[key])) {
          throw new Error(`${rule.id}.${key} must be a string array`);
        }
        if (isStringArray(rule[key]) && rule[key].some((s) => /[A-Z]/.test(s) || s === "")) {
          throw new Error(`${rule.id}.${key} entries must be non-empty lower-case strings`);
        }
      }
    }
    if (v.protection === void 0) v.protection = EMPTY_PROTECTION;
    const p = v.protection;
    if (typeof p !== "object" || p === null || Array.isArray(p)) throw new Error("protection must be an object");
    rejectUnknownKeys(
      p,
      [
        "description",
        "domains",
        "pathKeywords",
        "pathSubstrings",
        "params",
        "paramPrefixes",
        "paramSuffixes",
        "paramCombinations",
        "experimentalParams"
      ],
      "protection"
    );
    if (p.description !== void 0 && typeof p.description !== "string") {
      throw new Error("protection.description must be a string");
    }
    for (const key of [
      "domains",
      "pathKeywords",
      "pathSubstrings",
      "params",
      "paramPrefixes",
      "paramSuffixes"
    ]) {
      if (!isStringArray(p[key])) throw new Error(`protection.${key} must be a string array`);
    }
    if (p.experimentalParams !== void 0 && !isStringArray(p.experimentalParams)) {
      throw new Error("protection.experimentalParams must be a string array");
    }
    if (!Array.isArray(p.paramCombinations) || !p.paramCombinations.every(isStringArray)) {
      throw new Error("protection.paramCombinations must be an array of string arrays");
    }
    const lists = [
      ...["domains", "pathKeywords", "pathSubstrings", "params", "paramPrefixes", "paramSuffixes"].map(
        (k) => p[k]
      ),
      ...p.paramCombinations,
      p.experimentalParams ?? []
    ];
    for (const list of lists) {
      if (list.some((s) => s === "" || /[A-Z]/.test(s))) {
        throw new Error("protection entries must be non-empty lower-case strings");
      }
    }
    if (p.paramCombinations.some((c) => c.length === 0)) {
      throw new Error("protection.paramCombinations entries must not be empty");
    }
    return value;
  }
  var defaultRuleSet = validateRuleSet(rules_default);

  // ../../packages/core/src/engine.ts
  function escapeRegExp(s) {
    return s.replace(/[.*+?^${}()|[\]\\/-]/g, "\\$&");
  }
  function asciiLower(s) {
    return s.replace(/[A-Z]/g, (c) => String.fromCharCode(c.charCodeAt(0) + 32));
  }
  function percentDecodeOr(raw) {
    try {
      return decodeURIComponent(raw);
    } catch {
      return raw;
    }
  }
  function normaliseKey(rawKey) {
    const spaced = rawKey.replace(/\+/g, " ");
    return asciiLower(spaced.includes("%") ? percentDecodeOr(spaced) : spaced);
  }
  function domainMatches(host, domain) {
    return host === domain || host.length > domain.length && host.endsWith("." + domain);
  }
  function normaliseException(entry) {
    let e = asciiLower(trimC0(entry));
    if (e.startsWith("*.")) e = e.slice(2);
    if (e === "") return "";
    let host;
    try {
      host = new URL(e.includes("://") ? e : `http://${e}`).hostname;
    } catch {
      return "";
    }
    const h = stripTrailingDots(asciiLower(host));
    return isSaneHost(h) ? h : "";
  }
  function isSaneHost(host) {
    return /^(?:[a-z0-9_.-]+|\[[0-9a-f:.]+\])$/.test(host);
  }
  function stripTrailingDots(host) {
    let h = host;
    while (h.endsWith(".")) h = h.slice(0, -1);
    return h;
  }
  function encodeTrailingWhitespace(url) {
    let end = url.length;
    while (end > 0 && url.charCodeAt(end - 1) <= 32) end--;
    if (end === url.length) return url;
    let tail = "";
    for (let i = end; i < url.length; i++) {
      tail += "%" + url.charCodeAt(i).toString(16).toUpperCase().padStart(2, "0");
    }
    return url.slice(0, end) + tail;
  }
  function trimC0(s) {
    let start = 0;
    let end = s.length;
    while (start < end && s.charCodeAt(start) <= 32) start++;
    while (end > start && s.charCodeAt(end - 1) <= 32) end--;
    return s.slice(start, end);
  }
  function rawKeyOf(segment) {
    const eq = segment.indexOf("=");
    return eq === -1 ? segment : segment.slice(0, eq);
  }
  function isParamShapedFragment(fragment) {
    return fragment.includes("=") && !fragment.includes("/") && !fragment.includes("?") && !fragment.startsWith(":~:");
  }
  function stripParts(input, prefix, query, fragment) {
    const segments = (query ?? "").split("&").filter((seg) => seg !== "");
    if (segments.length === 0) return { url: input, changed: false, status: "unchanged", removed: [] };
    const removed = segments.map((seg) => ({
      name: rawKeyOf(seg),
      location: "query",
      ruleId: EXPERIMENTAL_RULE_ID
    }));
    const url = encodeTrailingWhitespace(prefix + (fragment === void 0 ? "" : "#" + fragment));
    return { url, changed: url !== input, status: "cleaned", removed };
  }
  function splitRaw(trimmed) {
    const hashIdx = trimmed.indexOf("#");
    const fragmentStart = hashIdx === -1 ? trimmed.length : hashIdx;
    const qIdx = trimmed.indexOf("?");
    const queryStart = qIdx !== -1 && qIdx < fragmentStart ? qIdx : -1;
    return {
      prefix: trimmed.slice(0, queryStart === -1 ? fragmentStart : queryStart),
      query: queryStart === -1 ? void 0 : trimmed.slice(queryStart + 1, fragmentStart),
      fragment: hashIdx === -1 ? void 0 : trimmed.slice(hashIdx + 1)
    };
  }
  function stripQuery(input) {
    const unchanged = (status) => ({ url: input, changed: false, status, removed: [] });
    if (typeof input !== "string") return unchanged("invalid");
    const trimmed = trimC0(input);
    if (/[\t\n\r]/.test(trimmed)) return unchanged("invalid");
    let parsed;
    try {
      parsed = new URL(trimmed);
    } catch {
      return unchanged("invalid");
    }
    if (parsed.protocol !== "http:" && parsed.protocol !== "https:") return unchanged("unsupported");
    if (!isSaneHost(asciiLower(parsed.hostname))) return unchanged("invalid");
    const { prefix, query, fragment } = splitRaw(trimmed);
    return stripParts(input, prefix, query, fragment);
  }
  function valueIsUrl(segment) {
    const eq = segment.indexOf("=");
    if (eq === -1) return false;
    const v = asciiLower(segment.slice(eq + 1, eq + 1 + 14));
    return ["http://", "https://", "http%3a%2f%2f", "https%3a%2f%2f"].some((x) => v.startsWith(x));
  }
  var EXPERIMENTAL_RULE_ID = "experimental";
  var Cleaner = class {
    ruleSet;
    compiled;
    pathKeywordRes;
    protectedParams;
    experimentalParams;
    constructor(ruleSet = defaultRuleSet) {
      this.ruleSet = ruleSet;
      this.compiled = ruleSet.rules.map((rule) => ({
        rule,
        params: new Set(rule.params ?? []),
        prefixes: rule.prefixes ?? [],
        domains: rule.domains
      }));
      this.pathKeywordRes = ruleSet.protection.pathKeywords.map((kw) => ({
        kw,
        re: new RegExp(`(^|[/_.-])(${escapeRegExp(kw)})($|[/_.0-9-])`)
      }));
      this.protectedParams = new Set(ruleSet.protection.params);
      this.experimentalParams = new Set(ruleSet.protection.experimentalParams ?? []);
    }
    clean(input, options = {}) {
      const mode = options.mode ?? "clean";
      const unchanged = (status, reason2) => reason2 === void 0 ? { url: input, changed: false, status, removed: [] } : { url: input, changed: false, status, removed: [], reason: reason2 };
      if (typeof input !== "string") return unchanged("invalid");
      const trimmed = trimC0(input);
      if (/[\t\n\r]/.test(trimmed)) return unchanged("invalid");
      let parsed;
      try {
        parsed = new URL(trimmed);
      } catch {
        return unchanged("invalid");
      }
      if (parsed.protocol !== "http:" && parsed.protocol !== "https:") return unchanged("unsupported");
      if (!isSaneHost(asciiLower(parsed.hostname))) return unchanged("invalid");
      if (mode === "bypass") return unchanged("bypassed");
      const host = stripTrailingDots(asciiLower(parsed.hostname));
      for (const entry of options.exceptions ?? []) {
        const ex = normaliseException(entry);
        if (ex !== "" && domainMatches(host, ex)) return unchanged("excepted");
      }
      const { prefix, query, fragment } = splitRaw(trimmed);
      const reason = this.protectionReason(host, parsed.pathname, query, fragment, mode === "experimental");
      if (reason !== void 0) return unchanged("protected", reason);
      if (mode === "experimental") return stripParts(input, prefix, query, fragment);
      const applicable = this.compiled.filter(
        (c) => (c.rule.mode === "clean" || mode === "strict") && (c.domains === void 0 || c.domains.some((d) => domainMatches(host, d)))
      );
      const removed = [];
      const cleanPart = (part, location) => part.split("&").filter((segment) => {
        const rawKey = rawKeyOf(segment);
        const key = normaliseKey(rawKey);
        const match = applicable.find((c) => c.params.has(key) || c.prefixes.some((p) => key.startsWith(p)));
        if (match === void 0) return true;
        removed.push({ name: rawKey, location, ruleId: match.rule.id });
        return false;
      }).join("&");
      const newQuery = query === void 0 ? void 0 : cleanPart(query, "query");
      const removedFromQuery = removed.length;
      const newFragment = fragment !== void 0 && mode === "strict" && isParamShapedFragment(fragment) ? cleanPart(fragment, "fragment") : fragment;
      const removedFromFragment = removed.length - removedFromQuery;
      if (removed.length === 0) return unchanged("unchanged");
      let url = prefix;
      if (newQuery !== void 0 && !(newQuery === "" && removedFromQuery > 0)) url += "?" + newQuery;
      if (newFragment !== void 0 && !(newFragment === "" && removedFromFragment > 0)) url += "#" + newFragment;
      url = encodeTrailingWhitespace(url);
      return { url, changed: url !== input, status: "cleaned", removed };
    }
    protectionReason(host, pathname, query, fragment, experimental) {
      const p = this.ruleSet.protection;
      const domain = p.domains.find((d) => domainMatches(host, d));
      if (domain !== void 0) return `domain:${domain}`;
      const path = asciiLower(percentDecodeOr(pathname));
      const kw = this.pathKeywordRes.find(({ re }) => re.test(path));
      if (kw !== void 0) return `path:${kw.kw}`;
      const sub = p.pathSubstrings.find((x) => path.includes(x));
      if (sub !== void 0) return `path:${sub}`;
      const keys = [];
      if (query !== void 0) for (const seg of query.split("&")) keys.push(normaliseKey(rawKeyOf(seg)));
      if (fragment !== void 0 && fragment.includes("=")) {
        for (const seg of fragment.split("&")) keys.push(normaliseKey(rawKeyOf(seg)));
      }
      for (const key of keys) {
        if (key === "") continue;
        if (this.protectedParams.has(key) || experimental && this.experimentalParams.has(key) || p.paramPrefixes.some((x) => key.startsWith(x)) || p.paramSuffixes.some((x) => key.endsWith(x))) {
          return `param:${key}`;
        }
      }
      const keySet = new Set(keys);
      const combo = p.paramCombinations.find((c) => c.every((k) => keySet.has(k)));
      if (combo !== void 0) return `combination:${combo.join("+")}`;
      if (experimental) {
        const segments = [...query?.split("&") ?? [], ...fragment?.includes("=") ? fragment.split("&") : []];
        if (segments.some(valueIsUrl)) return "value:url";
      }
      return void 0;
    }
  };
  var defaultCleaner = new Cleaner();
  function cleanUrl(input, options = {}) {
    return defaultCleaner.clean(input, options);
  }

  // ../../packages/core/src/dnr.ts
  var PRIORITY = {
    caseInsensitiveFallback: 1,
    /** `allow` that stops the one-per-hop fallback chain on very long queries. */
    fallbackGuard: 2,
    globalRedirect: 3,
    domainRedirect: 4,
    protection: 5,
    userException: 6,
    /** Reserved for per-tab session rules created by the extension. */
    tabPause: 7
  };
  var ID_BASE = {
    globalRedirect: 1,
    /** Experimental mode: the single query-stripping redirect. */
    stripQuery: 50,
    domainRedirect: 100,
    caseInsensitiveFallback: 500,
    fallbackGuard: 999,
    protection: 1e3,
    userException: 2e3
  };
  var FALLBACK_CHUNK = 4;
  var REGEX_CHUNK = 6;
  var REGEX_CHUNK_CHARS = 60;
  var MAX_FALLBACK_SEGMENTS = 6;
  function escapeRe2(s) {
    return s.replace(/[.*+?^${}()|[\]\\/-]/g, "\\$&");
  }
  function chunkWords(words, size = REGEX_CHUNK, maxChars = REGEX_CHUNK_CHARS) {
    const out = [];
    let current = [];
    let chars = 0;
    for (const w of words) {
      const len = escapeRe2(w).length + 1;
      if (current.length > 0 && (current.length >= size || chars + len > maxChars)) {
        out.push(current);
        current = [];
        chars = 0;
      }
      current.push(w);
      chars += len;
    }
    if (current.length > 0) out.push(current);
    return out;
  }
  function chunk(items, size) {
    const out = [];
    for (let i = 0; i < items.length; i += size) out.push(items.slice(i, i + size));
    return out;
  }
  function toAsciiDomain(entry) {
    const host = normaliseException(entry);
    if (host === "") return "";
    try {
      const u = new URL(`http://${host}/`);
      if (u.hostname.startsWith("[")) return "";
      if (u.port !== "" || u.username !== "" || u.pathname !== "/" || asciiLower(u.hostname) !== u.hostname) return "";
      return host;
    } catch {
      return "";
    }
  }
  function applies(rule, mode) {
    return mode !== "experimental" && (rule.mode === "clean" || mode === "strict");
  }
  function stripQueryRule() {
    return {
      id: ID_BASE.stripQuery,
      priority: PRIORITY.globalRedirect,
      action: { type: "redirect", redirect: { transform: { query: "" } } },
      condition: { resourceTypes: ["main_frame"], requestMethods: ["get"], regexFilter: "^[^?#]*\\?[^#]*[^&#]" }
    };
  }
  function uniq(items) {
    return [...new Set(items)];
  }
  function withCaseVariants(params) {
    return uniq(params.flatMap((p) => [p, p.toUpperCase()]));
  }
  function compileDnrRules(settings, ruleSet = defaultRuleSet) {
    const rules = [];
    const experimental = settings.mode === "experimental";
    if (experimental) rules.push(stripQueryRule());
    const active = ruleSet.rules.filter((r) => applies(r, settings.mode));
    const globalParams = uniq(active.filter((r) => r.domains === void 0).flatMap((r) => r.params ?? []));
    if (globalParams.length > 0) {
      rules.push({
        id: ID_BASE.globalRedirect,
        priority: PRIORITY.globalRedirect,
        action: {
          type: "redirect",
          redirect: { transform: { queryTransform: { removeParams: withCaseVariants(globalParams) } } }
        },
        // No regexFilter here on purpose: Chromium only falls through from a
        // no-op redirect to a lower-priority rule of the *other* matcher kind
        // (URL-pattern vs regex). Keeping the exact rules regex-free lets the
        // regex fallback run after them (verified in the e2e suite).
        condition: { resourceTypes: ["main_frame"] }
      });
    }
    const domains = uniq(active.flatMap((r) => r.domains ?? []));
    domains.forEach((domain, i) => {
      const params = uniq([
        ...globalParams,
        ...active.filter((r) => r.domains?.some((d) => domainMatches(domain, d))).flatMap((r) => r.params ?? [])
      ]);
      rules.push({
        id: ID_BASE.domainRedirect + i,
        priority: PRIORITY.domainRedirect,
        action: {
          type: "redirect",
          redirect: { transform: { queryTransform: { removeParams: withCaseVariants(params) } } }
        },
        condition: { resourceTypes: ["main_frame"], requestDomains: [domain] }
      });
    });
    const patternsOf = (rs) => uniq([
      ...rs.flatMap((r) => (r.prefixes ?? []).map((x) => `${escapeRe2(x)}[^=&#]*`)),
      ...rs.flatMap((r) => (r.params ?? []).map(escapeRe2))
    ]);
    const fallbackGroups = [
      { patterns: patternsOf(active.filter((r) => r.domains === void 0)) },
      ...active.filter((r) => r.domains !== void 0).map((r) => ({ domains: [...r.domains ?? []], patterns: patternsOf([r]) }))
    ];
    let fid = ID_BASE.caseInsensitiveFallback;
    for (const { domains: requestDomains, patterns } of fallbackGroups) {
      for (const group of chunk(patterns, FALLBACK_CHUNK)) {
        const names = `(?:${group.join("|")})`;
        const variants = [
          // tracker followed by more parameters: drop it and its '&'
          [`^([^?#]*\\?(?:[^&#]*&)*?)${names}(?:=[^&#]*)?&(.*)$`, "\\1\\2"],
          // last parameter after others: drop it and the preceding '&'
          [`^([^?#]*\\?[^#]*?)&${names}(?:=[^&#]*)?(#.*)?$`, "\\1\\2"],
          // the only parameter: drop it and the '?'
          [`^([^?#]*)\\?${names}(?:=[^&#]*)?(#.*)?$`, "\\1\\2"]
        ];
        for (const [regexFilter, regexSubstitution] of variants) {
          rules.push({
            id: fid++,
            priority: PRIORITY.caseInsensitiveFallback,
            action: { type: "redirect", redirect: { regexSubstitution } },
            condition: {
              resourceTypes: ["main_frame"],
              ...requestDomains === void 0 ? {} : { requestDomains },
              regexFilter,
              isUrlFilterCaseSensitive: false
            }
          });
        }
      }
    }
    if (fid >= ID_BASE.fallbackGuard) throw new Error("too many fallback rules for the reserved id range");
    if (!experimental)
      rules.push({
        id: ID_BASE.fallbackGuard,
        priority: PRIORITY.fallbackGuard,
        action: { type: "allow" },
        condition: { resourceTypes: ["main_frame"], regexFilter: `\\?(?:[^&]*&){${MAX_FALLBACK_SEGMENTS}}` }
      });
    const p = ruleSet.protection;
    let pid = ID_BASE.protection;
    const allow = (condition) => {
      rules.push({
        id: pid++,
        priority: PRIORITY.protection,
        action: { type: "allow" },
        condition: { resourceTypes: ["main_frame"], ...condition }
      });
    };
    if (p.domains.length > 0) allow({ requestDomains: [...p.domains] });
    for (const group of chunkWords(p.pathKeywords)) {
      allow({
        regexFilter: `^https?://[^/?#]*/(?:[^?#]*[/_.-])?(?:${group.map(escapeRe2).join("|")})(?:[/_.0-9?#-]|$)`,
        isUrlFilterCaseSensitive: false
      });
    }
    for (const group of chunkWords(p.pathSubstrings)) {
      allow({
        regexFilter: `^https?://[^/?#]*/[^?#]*(?:${group.map(escapeRe2).join("|")})`,
        isUrlFilterCaseSensitive: false
      });
    }
    const encodedWordChar = "%(?:[46][1-9a-f]|[57][0-9a]|2[def]|3[0-9]|5f)";
    allow({ regexFilter: `^https?://[^/?#]*/[^?#]*${encodedWordChar}`, isUrlFilterCaseSensitive: false });
    allow({ regexFilter: `[?&#][^=&#]*${encodedWordChar}`, isUrlFilterCaseSensitive: false });
    if (experimental) {
      allow({ regexFilter: "[?&#][^=&#]*=https?(?::|%3a)(?:/|%2f)(?:/|%2f)", isUrlFilterCaseSensitive: false });
    }
    const protectedParams = experimental ? [...p.params, ...p.experimentalParams ?? []] : p.params;
    for (const group of chunkWords(protectedParams)) {
      const names = group.map(escapeRe2).join("|");
      allow({ regexFilter: `[?&#](?:${names})(?:[=&#]|$)`, isUrlFilterCaseSensitive: false });
    }
    if (p.paramPrefixes.length > 0) {
      const names = p.paramPrefixes.map(escapeRe2).join("|");
      allow({ regexFilter: `[?&#](?:${names})`, isUrlFilterCaseSensitive: false });
    }
    if (p.paramSuffixes.length > 0) {
      const names = p.paramSuffixes.map(escapeRe2).join("|");
      allow({ regexFilter: `[?&#][^=&#]*(?:${names})(?:[=&#]|$)`, isUrlFilterCaseSensitive: false });
    }
    for (const combo of p.paramCombinations) {
      if (combo.length !== 2) continue;
      const [x, y] = combo.map(escapeRe2);
      const pair = (a, b) => `[?&#]${a}(?:=[^&#]*)?[&#](?:.*[&#])?${b}(?:[=&#]|$)`;
      allow({ regexFilter: `${pair(x, y)}|${pair(y, x)}`, isUrlFilterCaseSensitive: false });
    }
    const exceptions = uniq(settings.exceptions.map(toAsciiDomain).filter((d) => d !== ""));
    if (exceptions.length > 0) {
      rules.push({
        id: ID_BASE.userException,
        priority: PRIORITY.userException,
        action: { type: "allow" },
        condition: { resourceTypes: ["main_frame"], requestDomains: exceptions }
      });
    }
    return rules;
  }

  // src/settings.ts
  var DEFAULT_SETTINGS = Object.freeze({
    enabled: true,
    mode: "clean",
    exceptions: [],
    pausedUntil: 0,
    copyCleaning: true
  });
  var MAX_EXCEPTIONS = 1e3;
  function sanitizeExceptions(entries) {
    const out = /* @__PURE__ */ new Set();
    for (const entry of entries) {
      if (typeof entry !== "string" || entry.length > 2048) continue;
      const domain = toAsciiDomain(entry);
      if (domain !== "" && domain.length <= 253) out.add(domain);
      if (out.size >= MAX_EXCEPTIONS) break;
    }
    return [...out].sort();
  }
  function sanitizeSettings(raw) {
    const r = typeof raw === "object" && raw !== null ? raw : {};
    const pausedUntil = typeof r.pausedUntil === "number" && Number.isFinite(r.pausedUntil) && r.pausedUntil > 0 ? r.pausedUntil : 0;
    return {
      enabled: typeof r.enabled === "boolean" ? r.enabled : DEFAULT_SETTINGS.enabled,
      mode: r.mode === "strict" || r.mode === "experimental" ? r.mode : "clean",
      exceptions: Array.isArray(r.exceptions) ? sanitizeExceptions(r.exceptions) : [],
      pausedUntil,
      copyCleaning: typeof r.copyCleaning === "boolean" ? r.copyCleaning : DEFAULT_SETTINGS.copyCleaning
    };
  }
  function effectiveMode(s, now = Date.now()) {
    if (!s.enabled || s.pausedUntil > now) return "bypass";
    return s.mode;
  }
  var SETTINGS_KEYS = Object.keys(DEFAULT_SETTINGS);
  async function loadSettings() {
    const stored = await chrome.storage.local.get(SETTINGS_KEYS);
    return sanitizeSettings({ ...DEFAULT_SETTINGS, ...stored });
  }
  async function saveSettings(patch) {
    const next = sanitizeSettings({ ...await loadSettings(), ...patch });
    const keys = Object.keys(patch).filter((k) => SETTINGS_KEYS.includes(k));
    await chrome.storage.local.set(Object.fromEntries(keys.map((k) => [k, next[k]])));
    return next;
  }

  // src/background.ts
  var RESUME_ALARM = "untrackable-resume";
  var MAX_URL_LENGTH = 32768;
  var rulesDegraded = false;
  var MENU = {
    copyLink: "copy-clean-link",
    openUnmodified: "open-link-unmodified",
    copyPage: "copy-clean-page-link",
    copyStripped: "copy-link-without-query",
    openStripped: "open-link-without-query"
  };
  var applyQueue = Promise.resolve();
  function applyRules() {
    applyQueue = applyQueue.then(applyRulesNow, applyRulesNow);
    return applyQueue;
  }
  async function supportedRules(rules) {
    const kept = [];
    let protectionBroken = false;
    let stripBroken = false;
    for (const rule of rules) {
      const regex = rule.condition.regexFilter;
      if (regex !== void 0) {
        const { isSupported } = await chrome.declarativeNetRequest.isRegexSupported({
          regex,
          // Chromium's default for regex rules is case-insensitive (Chrome 118+).
          isCaseSensitive: rule.condition.isUrlFilterCaseSensitive === true,
          requireCapturing: rule.action.redirect?.regexSubstitution !== void 0
        });
        if (!isSupported) {
          if (rule.action.type === chrome.declarativeNetRequest.RuleActionType.ALLOW) protectionBroken = true;
          if (rule.id === ID_BASE.stripQuery) stripBroken = true;
          continue;
        }
      }
      kept.push(rule);
    }
    rulesDegraded = protectionBroken || stripBroken;
    return protectionBroken ? kept.filter((r) => r.action.type !== chrome.declarativeNetRequest.RuleActionType.REDIRECT) : kept;
  }
  async function applyRulesNow() {
    rulesDegraded = false;
    const settings = await loadSettings();
    const mode = effectiveMode(settings);
    const compiled = mode === "bypass" ? [] : await supportedRules(
      compileDnrRules({ mode, exceptions: settings.exceptions })
    );
    const existing = await chrome.declarativeNetRequest.getDynamicRules();
    const removeRuleIds = existing.map((r) => r.id);
    try {
      await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds, addRules: compiled });
    } catch {
      const essential = compiled.filter((r) => r.action.redirect?.regexSubstitution === void 0);
      try {
        await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds, addRules: essential });
      } catch {
        rulesDegraded = true;
        await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds }).catch(() => {
        });
      }
    }
    await scheduleResume(settings);
    await updateBadge(settings);
  }
  async function scheduleResume(settings) {
    await chrome.alarms.clear(RESUME_ALARM);
    if (settings.pausedUntil > Date.now()) {
      await chrome.alarms.create(RESUME_ALARM, { when: settings.pausedUntil });
    }
  }
  async function updateBadge(settings) {
    const mode = effectiveMode(settings);
    if (rulesDegraded && mode !== "bypass") {
      await chrome.action.setBadgeText({ text: "!" });
      await chrome.action.setBadgeBackgroundColor({ color: "#8a3b12" });
      await chrome.action.setTitle({
        title: "Untrackable \u2013 navigation cleaning disabled: this browser could not install the cleaning or protection rules"
      });
      return;
    }
    const text = { bypass: "off", strict: "S", experimental: "E", clean: "" }[mode];
    await chrome.action.setBadgeText({ text });
    await chrome.action.setBadgeBackgroundColor({
      color: mode === "bypass" ? "#8a3b12" : mode === "experimental" ? "#5b2a86" : "#1f5f3a"
    });
    const title = mode === "bypass" ? settings.enabled ? "Untrackable \u2013 paused" : "Untrackable \u2013 off" : mode === "experimental" ? "Untrackable \u2013 Experimental mode: removes all query parameters (sites may break)" : `Untrackable \u2013 ${mode === "strict" ? "Strict" : "Clean"} mode`;
    await chrome.action.setTitle({ title });
  }
  var ONCE_BASE = 1e9;
  var ONCE_ALARM_PREFIX = "untrackable-once-";
  var ONCE_TIMEOUT_MINUTES = 1;
  var sessionQueue = Promise.resolve();
  function serialised(fn) {
    const run = sessionQueue.then(fn, fn);
    sessionQueue = run.catch(() => {
    });
    return run;
  }
  function kindOf(id) {
    return id >= ONCE_BASE ? "once" : "pause";
  }
  async function tabRules(tabId) {
    return (await chrome.declarativeNetRequest.getSessionRules()).filter((r) => r.condition.tabIds?.includes(tabId));
  }
  async function setTabRule(tabId, kind, present, requestDomains) {
    const all = await chrome.declarativeNetRequest.getSessionRules();
    const remove = all.filter((r) => kindOf(r.id) === kind && r.condition.tabIds?.includes(tabId)).map((r) => r.id);
    const addRules = [];
    if (present) {
      const base = kind === "once" ? ONCE_BASE : 1;
      const used = new Set(all.map((r) => r.id));
      let id = base;
      while (used.has(id)) id++;
      addRules.push({
        id,
        priority: PRIORITY.tabPause,
        action: { type: chrome.declarativeNetRequest.RuleActionType.ALLOW },
        condition: {
          tabIds: [tabId],
          resourceTypes: [chrome.declarativeNetRequest.ResourceType.MAIN_FRAME],
          ...requestDomains === void 0 ? {} : { requestDomains }
        }
      });
    }
    if (remove.length > 0 || addRules.length > 0) {
      await chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: remove, addRules });
    }
  }
  function setTabPaused(tabId, paused) {
    return serialised(async () => {
      await setTabRule(tabId, "pause", paused);
      if (!paused) await setTabRule(tabId, "once", false);
      if (!paused) await chrome.alarms.clear(ONCE_ALARM_PREFIX + tabId);
    });
  }
  function endOnce(tabId) {
    return serialised(async () => {
      const rules = await tabRules(tabId);
      if (!rules.some((r) => kindOf(r.id) === "once")) return;
      await setTabRule(tabId, "once", false);
      await chrome.alarms.clear(ONCE_ALARM_PREFIX + tabId);
    });
  }
  async function openUnmodified(url, openerTab) {
    if (!/^https?:/i.test(url)) return;
    const createProps = { url: "about:blank", active: true };
    if (openerTab?.id !== void 0) createProps.openerTabId = openerTab.id;
    if (openerTab?.index !== void 0) createProps.index = openerTab.index + 1;
    const tab = await chrome.tabs.create(createProps);
    if (tab.id === void 0) return;
    const tabId = tab.id;
    await waitForTab(tabId, (t) => t.status === "complete");
    await serialised(() => setTabRule(tabId, "once", true));
    await chrome.alarms.create(ONCE_ALARM_PREFIX + tabId, { delayInMinutes: ONCE_TIMEOUT_MINUTES });
    await chrome.tabs.update(tabId, { url });
  }
  async function waitForTab(tabId, done, timeoutMs = 3e3) {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      const tab = await chrome.tabs.get(tabId).catch(() => void 0);
      if (tab === void 0) return false;
      if (done(tab)) return true;
      await new Promise((r) => setTimeout(r, 50));
    }
    return false;
  }
  chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    const committedUrl = changeInfo.url !== void 0 && changeInfo.url !== "about:blank";
    const completed = changeInfo.status === "complete" && tab.url !== void 0 && tab.url !== "about:blank";
    if (committedUrl || completed) void endOnce(tabId);
  });
  var REDIRECT_LOOP_ERROR = "net::ERR_TOO_MANY_REDIRECTS";
  var LOOP_RETRY_KEY = "loopRetries";
  var LOOP_OFFER_KEY = "loopOffers";
  var LOOP_PURGE_ALARM = "untrackable-loop-purge";
  var LOOP_RETRY_WINDOW_MS = 6e4;
  var LOOP_OFFER_TTL_MS = 10 * 6e4;
  async function readLoopOffers() {
    const raw = (await chrome.storage.session.get(LOOP_OFFER_KEY))[LOOP_OFFER_KEY];
    const out = {};
    if (typeof raw === "object" && raw !== null) {
      for (const [k, v] of Object.entries(raw)) {
        const o = v;
        if (typeof o?.host === "string" && typeof o.at === "number" && Date.now() - o.at < LOOP_OFFER_TTL_MS) {
          out[k] = o.notOurs === true ? { host: o.host, at: o.at, notOurs: true } : { host: o.host, at: o.at };
        }
      }
    }
    return out;
  }
  function setLoopOffer(tabId, host, notOurs = false) {
    return serialised(async () => {
      const offers = Object.fromEntries(
        Object.entries(await readLoopOffers()).filter(([k]) => k !== String(tabId))
      );
      if (host !== void 0) {
        offers[String(tabId)] = notOurs ? { host, at: Date.now(), notOurs: true } : { host, at: Date.now() };
      }
      await chrome.storage.session.set({ [LOOP_OFFER_KEY]: offers });
      await chrome.alarms.clear(LOOP_PURGE_ALARM);
      if (Object.keys(offers).length > 0) {
        const oldest = Math.min(...Object.values(offers).map((o) => o.at));
        await chrome.alarms.create(LOOP_PURGE_ALARM, { when: oldest + LOOP_OFFER_TTL_MS + 1e3 });
      }
      await chrome.action.setBadgeText({ tabId, text: host === void 0 ? null : "\u21BB" }).catch(() => {
      });
      if (host !== void 0) {
        await chrome.action.setTitle({
          tabId,
          title: notOurs ? "Untrackable \u2013 this page still fails with cleaning off for this site; the loop is probably not caused by Untrackable." : "Untrackable \u2013 this page failed with too many redirects. Open for options."
        }).catch(() => {
        });
      }
    });
  }
  async function purgeLoopOffers() {
    const before = (await chrome.storage.session.get(LOOP_OFFER_KEY))[LOOP_OFFER_KEY];
    const live = await readLoopOffers();
    for (const tabId of Object.keys(before ?? {})) {
      if (!(tabId in live)) await setLoopOffer(Number(tabId), void 0);
    }
  }
  async function loopOfferHost(tabId) {
    return (await readLoopOffers())[String(tabId)]?.host;
  }
  async function loopOffer(tabId) {
    return (await readLoopOffers())[String(tabId)];
  }
  function claimLoopRetry(tabId, host) {
    return serialised(async () => {
      const now = Date.now();
      const raw = (await chrome.storage.session.get(LOOP_RETRY_KEY))[LOOP_RETRY_KEY];
      const retries = pruneRetries(raw, now);
      const claimed = retries[String(tabId)] === void 0;
      if (claimed) retries[String(tabId)] = { at: now, host };
      await chrome.storage.session.set({ [LOOP_RETRY_KEY]: retries });
      return claimed;
    });
  }
  function pruneRetries(raw, now) {
    const retries = {};
    if (typeof raw === "object" && raw !== null) {
      for (const [k, v] of Object.entries(raw)) {
        const r = v;
        if (typeof r?.at === "number" && typeof r.host === "string" && now - r.at < LOOP_RETRY_WINDOW_MS) {
          retries[k] = { at: r.at, host: r.host };
        }
      }
    }
    return retries;
  }
  function clearLoopRetry(tabId) {
    return serialised(async () => {
      const raw = (await chrome.storage.session.get(LOOP_RETRY_KEY))[LOOP_RETRY_KEY];
      const retries = pruneRetries(raw, Date.now());
      if (retries[String(tabId)] === void 0) return;
      const rest = Object.fromEntries(Object.entries(retries).filter(([k]) => k !== String(tabId)));
      await chrome.storage.session.set({ [LOOP_RETRY_KEY]: rest });
    });
  }
  async function recentRetryHost(tabId) {
    const raw = (await chrome.storage.session.get(LOOP_RETRY_KEY))[LOOP_RETRY_KEY];
    return pruneRetries(raw, Date.now())[String(tabId)]?.host;
  }
  async function retryLoopWithoutCleaning(tabId) {
    const host = await loopOfferHost(tabId);
    if (host === void 0) return false;
    await setLoopOffer(tabId, void 0);
    if (!await claimLoopRetry(tabId, host)) return false;
    await serialised(() => setTabRule(tabId, "once", true, host.startsWith("[") ? void 0 : [host]));
    await chrome.alarms.create(ONCE_ALARM_PREFIX + tabId, { delayInMinutes: ONCE_TIMEOUT_MINUTES });
    await chrome.tabs.reload(tabId);
    return true;
  }
  async function onRedirectLoop(tabId, url) {
    const settings = await loadSettings();
    const mode = effectiveMode(settings);
    if (mode === "bypass" || url.length > MAX_URL_LENGTH || !/^https?:/i.test(url)) return;
    const { status } = cleanUrl(url, { mode, exceptions: settings.exceptions });
    if (status === "protected" || status === "excepted" || status === "invalid") return;
    let host;
    try {
      host = new URL(url).hostname.replace(/\.+$/, "");
    } catch {
      return;
    }
    if (host === "") return;
    const notOurs = await recentRetryHost(tabId) === host;
    await setLoopOffer(tabId, host, notOurs);
  }
  function onNavigationError(details) {
    if (details.frameId !== 0 || details.tabId < 0 || details.error !== REDIRECT_LOOP_ERROR) return;
    void onRedirectLoop(details.tabId, details.url);
  }
  function onNavigationCommitted(details) {
    if (details.frameId !== 0 || details.tabId < 0) return;
    void loopOfferHost(details.tabId).then((h) => h === void 0 ? void 0 : setLoopOffer(details.tabId, void 0));
    void clearLoopRetry(details.tabId);
  }
  function registerLoopRecovery() {
    const nav = chrome.webNavigation;
    if (nav === void 0) return;
    if (!nav.onErrorOccurred.hasListener(onNavigationError)) nav.onErrorOccurred.addListener(onNavigationError);
    if (!nav.onCommitted.hasListener(onNavigationCommitted)) nav.onCommitted.addListener(onNavigationCommitted);
  }
  registerLoopRecovery();
  chrome.permissions.onAdded.addListener(registerLoopRecovery);
  chrome.permissions.onRemoved.addListener(() => {
    void (async () => {
      for (const tabId of Object.keys(await readLoopOffers())) await setLoopOffer(Number(tabId), void 0);
    })();
  });
  chrome.tabs.onRemoved.addListener((tabId) => {
    void readLoopOffers().then((offers) => offers[String(tabId)] ? setLoopOffer(tabId, void 0) : void 0);
    void serialised(async () => {
      await setTabRule(tabId, "pause", false);
      await setTabRule(tabId, "once", false);
    });
    void chrome.alarms.clear(ONCE_ALARM_PREFIX + tabId);
  });
  var creatingOffscreen;
  async function ensureOffscreen() {
    const url = chrome.runtime.getURL("offscreen.html");
    const contexts = await chrome.runtime.getContexts({
      contextTypes: [chrome.runtime.ContextType.OFFSCREEN_DOCUMENT],
      documentUrls: [url]
    });
    if (contexts.length > 0) return;
    creatingOffscreen ??= chrome.offscreen.createDocument({
      url: "offscreen.html",
      reasons: [chrome.offscreen.Reason.CLIPBOARD],
      justification: "Write the cleaned link to the clipboard after an explicit user action."
    }).finally(() => {
      creatingOffscreen = void 0;
    });
    await creatingOffscreen;
  }
  var clipboardQueue = Promise.resolve();
  function copyToClipboard(text, stillWanted = () => true) {
    const run = clipboardQueue.then(async () => {
      if (!stillWanted()) return false;
      await ensureOffscreen();
      if (!stillWanted()) return false;
      const ok = await chrome.runtime.sendMessage({ target: "offscreen", type: "copy", text });
      return ok === true;
    });
    clipboardQueue = run.catch(() => {
    });
    return run.catch(() => false);
  }
  var copySeq = 0;
  async function copyClean(url) {
    const seq = ++copySeq;
    if (url.length > MAX_URL_LENGTH) return;
    const settings = await loadSettings();
    const result = cleanUrl(url, { mode: settings.mode, exceptions: settings.exceptions });
    await copyToClipboard(result.url, () => seq === copySeq);
  }
  async function copyStripped(url) {
    const seq = ++copySeq;
    if (url.length > MAX_URL_LENGTH) return;
    const result = stripQuery(url);
    if (result.status !== "cleaned" && result.status !== "unchanged") return;
    await copyToClipboard(result.url, () => seq === copySeq);
  }
  async function openStripped(url, openerTab) {
    if (url.length > MAX_URL_LENGTH) return;
    const result = stripQuery(url);
    if (result.status !== "cleaned" && result.status !== "unchanged") return;
    const createProps = { url: result.url, active: true };
    if (openerTab?.id !== void 0) createProps.openerTabId = openerTab.id;
    if (openerTab?.index !== void 0) createProps.index = openerTab.index + 1;
    await chrome.tabs.create(createProps);
  }
  async function onCopiedLink(tabId, url) {
    const seq = ++copySeq;
    if (url === void 0) return;
    const settings = await loadSettings();
    if (!settings.enabled || !settings.copyCleaning) return;
    const effective = effectiveMode(settings);
    const mode = effective === "experimental" ? "strict" : effective;
    const active = mode !== "bypass" && (await tabRules(tabId)).length === 0;
    const result = active ? cleanUrl(url, { mode, exceptions: settings.exceptions }) : void 0;
    const text = result?.status === "cleaned" ? result.url : url;
    await copyToClipboard(text, () => seq === copySeq);
  }
  function createMenus() {
    chrome.contextMenus.removeAll(() => {
      chrome.contextMenus.create({ id: MENU.copyLink, title: "Copy clean link", contexts: ["link"] });
      chrome.contextMenus.create({ id: MENU.openUnmodified, title: "Open link without cleaning", contexts: ["link"] });
      chrome.contextMenus.create({ id: MENU.copyPage, title: "Copy clean page link", contexts: ["page"] });
      chrome.contextMenus.create({
        id: MENU.copyStripped,
        title: "Copy link without query parameters",
        contexts: ["link"]
      });
      chrome.contextMenus.create({
        id: MENU.openStripped,
        title: "Open link without query parameters",
        contexts: ["link"]
      });
    });
  }
  chrome.runtime.onInstalled.addListener(() => {
    createMenus();
    void applyRules();
  });
  chrome.runtime.onStartup.addListener(() => {
    void applyRules();
  });
  chrome.storage.onChanged.addListener((_changes, area) => {
    if (area === "local") void applyRules();
  });
  chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === RESUME_ALARM) void saveSettings({ pausedUntil: 0 });
    else if (alarm.name === LOOP_PURGE_ALARM) void purgeLoopOffers();
    else if (alarm.name.startsWith(ONCE_ALARM_PREFIX)) {
      const tabId = Number(alarm.name.slice(ONCE_ALARM_PREFIX.length));
      if (Number.isInteger(tabId)) void endOnce(tabId);
    }
  });
  chrome.contextMenus.onClicked.addListener((info, tab) => {
    if (info.menuItemId === MENU.copyLink && info.linkUrl) void copyClean(info.linkUrl);
    else if (info.menuItemId === MENU.openUnmodified && info.linkUrl) void openUnmodified(info.linkUrl, tab);
    else if (info.menuItemId === MENU.copyStripped && info.linkUrl) void copyStripped(info.linkUrl);
    else if (info.menuItemId === MENU.openStripped && info.linkUrl) void openStripped(info.linkUrl, tab);
    else if (info.menuItemId === MENU.copyPage) {
      const pageUrl = info.pageUrl ?? tab?.url;
      if (pageUrl !== void 0) void copyClean(pageUrl);
    }
  });
  chrome.commands.onCommand.addListener((command, tab) => {
    if (command !== "copy-clean-link" || tab?.url === void 0) return;
    void copyClean(tab.url);
  });
  function isMessage(m) {
    if (typeof m !== "object" || m === null) return false;
    const msg = m;
    switch (msg.type) {
      case "getTabState":
        return msg.tabId === void 0 || Number.isInteger(msg.tabId);
      case "setTabPaused":
        return Number.isInteger(msg.tabId) && typeof msg.paused === "boolean";
      case "copyText":
        return typeof msg.text === "string" && msg.text.length <= 32768;
      case "openUnmodified":
        return typeof msg.url === "string" && msg.url.length <= 32768;
      case "retryLoop":
        return Number.isInteger(msg.tabId);
      case "copied":
        return msg.url === void 0 || typeof msg.url === "string" && msg.url.length <= 8192;
      default:
        return false;
    }
  }
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (sender.id !== chrome.runtime.id || !isMessage(message)) return false;
    const fromExtensionPage = sender.url?.startsWith(chrome.runtime.getURL("")) === true;
    const fromContentScript = !fromExtensionPage;
    if (message.type === "getTabState") {
      const tabId = fromContentScript ? sender.tab?.id : message.tabId ?? sender.tab?.id;
      if (tabId === void 0) return false;
      void Promise.all([tabRules(tabId), fromContentScript ? void 0 : loopOffer(tabId)]).then(([rules, offer]) => {
        const state = {
          paused: rules.length > 0,
          pausedByUser: rules.some((r) => kindOf(r.id) === "pause")
        };
        if (offer !== void 0) {
          state.loopHost = offer.host;
          if (offer.notOurs === true) state.loopNotOurs = true;
        }
        sendResponse(state);
      });
      return true;
    }
    if (message.type === "copied") {
      if (!fromContentScript || sender.tab?.id === void 0) return false;
      void onCopiedLink(sender.tab.id, message.url);
      return false;
    }
    if (fromContentScript) return false;
    if (message.type === "setTabPaused") {
      void setTabPaused(message.tabId, message.paused).then(() => sendResponse(true));
      return true;
    }
    if (message.type === "copyText") {
      const seq = ++copySeq;
      void copyToClipboard(message.text, () => seq === copySeq).then(sendResponse);
      return true;
    }
    if (message.type === "openUnmodified") {
      void openUnmodified(message.url).then(() => sendResponse(true));
      return true;
    }
    if (message.type === "retryLoop") {
      void retryLoopWithoutCleaning(message.tabId).then(sendResponse);
      return true;
    }
    return false;
  });
  void applyRules();
})();
