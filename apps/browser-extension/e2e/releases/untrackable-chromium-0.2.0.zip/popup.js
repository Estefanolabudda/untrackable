"use strict";
(() => {
  // ../../rules/rules.json
  var rules_default = {
    schemaVersion: 1,
    rules: [
      {
        id: "utm",
        description: "Google Analytics / generic campaign parameters (utm_*)",
        mode: "clean",
        params: [
          "utm_source",
          "utm_medium",
          "utm_campaign",
          "utm_term",
          "utm_content",
          "utm_id",
          "utm_name",
          "utm_cid",
          "utm_reader",
          "utm_referrer",
          "utm_social",
          "utm_social-type",
          "utm_brand",
          "utm_place",
          "utm_pubreferrer",
          "utm_swu",
          "utm_viz_id",
          "utm_source_platform",
          "utm_creative_format",
          "utm_marketing_tactic"
        ],
        prefixes: ["utm_"]
      },
      {
        id: "click-ids",
        description: "Advertising click identifiers (Google, Meta, Microsoft, TikTok, X, Yandex, LinkedIn, Reddit)",
        mode: "clean",
        params: [
          "fbclid",
          "gclid",
          "gclsrc",
          "dclid",
          "gbraid",
          "wbraid",
          "gad_source",
          "gad_campaignid",
          "msclkid",
          "ttclid",
          "twclid",
          "yclid",
          "ysclid",
          "li_fat_id",
          "rdt_cid",
          "epik",
          "srsltid"
        ]
      },
      {
        id: "email-marketing",
        description: "Newsletter and marketing automation identifiers (Mailchimp, HubSpot, Marketo, Vero, Omeda, Openstat)",
        mode: "clean",
        params: [
          "mc_cid",
          "mc_eid",
          "_hsenc",
          "_hsmi",
          "__hssc",
          "__hstc",
          "__hsfp",
          "hsctatracking",
          "mkt_tok",
          "vero_id",
          "vero_conv",
          "oly_anon_id",
          "_openstat",
          "wickedid",
          "rb_clickid",
          "_ga",
          "_gl"
        ]
      },
      {
        id: "share-youtube-spotify",
        description: "Share-sheet identifiers that link a shared URL back to the sharer",
        mode: "clean",
        domains: ["youtube.com", "youtu.be", "spotify.com"],
        params: ["si"]
      },
      {
        id: "share-instagram",
        description: "Instagram share identifiers",
        mode: "clean",
        domains: ["instagram.com"],
        params: ["igsh", "igshid"]
      },
      {
        id: "share-x",
        description: "X / Twitter share tracking",
        mode: "clean",
        domains: ["x.com", "twitter.com"],
        params: ["s", "t"]
      },
      {
        id: "strict-generic",
        description: "Additional referral and analytics parameters (Matomo, Piwik, HubSpot Ads, comScore, Adobe, Branch, AT Internet, Alibaba). Strict mode only because some sites reuse these names functionally.",
        mode: "strict",
        params: [
          "ref",
          "ref_src",
          "ref_url",
          "referrer",
          "spm",
          "scm",
          "trk",
          "trkcampaign",
          "trackingid",
          "cmpid",
          "xtor",
          "ncid",
          "s_kwcid",
          "ef_id",
          "_branch_match_id",
          "_branch_referrer",
          "at_medium",
          "at_campaign",
          "sr_share",
          "igshid",
          "mibextid",
          "pk_campaign",
          "pk_kwd",
          "pk_keyword",
          "pk_source",
          "pk_medium",
          "pk_content",
          "pk_cid",
          "mtm_campaign",
          "mtm_keyword",
          "mtm_source",
          "mtm_medium",
          "mtm_content",
          "mtm_cid",
          "mtm_group",
          "mtm_placement",
          "piwik_campaign",
          "piwik_kwd",
          "hsa_acc",
          "hsa_cam",
          "hsa_grp",
          "hsa_ad",
          "hsa_src",
          "hsa_tgt",
          "hsa_kw",
          "hsa_mt",
          "hsa_net",
          "hsa_ver",
          "itm_source",
          "itm_medium",
          "itm_campaign",
          "itm_content",
          "itm_term",
          "oly_enc_id"
        ],
        prefixes: ["pk_", "mtm_", "piwik_", "hsa_", "itm_", "ns_"]
      },
      {
        id: "strict-amazon",
        description: "Amazon referral, placement and affiliate parameters",
        mode: "strict",
        domains: [
          "amazon.com",
          "amazon.de",
          "amazon.co.uk",
          "amazon.fr",
          "amazon.it",
          "amazon.es",
          "amazon.nl",
          "amazon.ca",
          "amazon.com.au",
          "amazon.co.jp",
          "amazon.in",
          "amazon.pl",
          "amazon.se",
          "amazon.com.be",
          "amazon.at"
        ],
        params: [
          "_encoding",
          "content-id",
          "crid",
          "dib",
          "dib_tag",
          "qid",
          "sprefix",
          "sr",
          "tag",
          "linkcode",
          "linkid",
          "ascsubtag",
          "creative",
          "creativeasin",
          "pf_rd_i",
          "pf_rd_m",
          "pf_rd_p",
          "pf_rd_r",
          "pf_rd_s",
          "pf_rd_t",
          "pd_rd_i",
          "pd_rd_r",
          "pd_rd_w",
          "pd_rd_wg",
          "pd_rd_plhdr"
        ],
        prefixes: ["pf_rd_", "pd_rd_"]
      },
      {
        id: "strict-google-search",
        description: "Google Search telemetry parameters (sa/usg are kept: google.com/url needs them for its redirect)",
        mode: "strict",
        domains: ["google.com", "google.de", "google.co.uk", "google.fr", "google.at", "google.ch"],
        params: [
          "ved",
          "ei",
          "sca_esv",
          "sxsrf",
          "oq",
          "gs_lp",
          "gs_lcrp",
          "sclient",
          "uact",
          "bih",
          "biw",
          "iflsig",
          "rlz",
          "sourceid",
          "aqs"
        ]
      },
      {
        id: "strict-social",
        description: "Facebook, LinkedIn, TikTok and Reddit share parameters",
        mode: "strict",
        domains: ["facebook.com", "linkedin.com", "tiktok.com", "reddit.com"],
        params: [
          "__tn__",
          "__cft__[0]",
          "rdid",
          "refid",
          "lipi",
          "_r",
          "_t",
          "is_from_webapp",
          "sender_device",
          "is_copy_url",
          "share_app_id",
          "share_id"
        ]
      },
      {
        id: "strict-ebay",
        description: "eBay tracking and partner network parameters",
        mode: "strict",
        domains: ["ebay.com", "ebay.de", "ebay.co.uk", "ebay.fr", "ebay.it", "ebay.es", "ebay.at"],
        params: ["_trkparms", "_trksid", "amdata", "mkcid", "mkevt", "mkrid", "campid", "toolid", "customid"]
      },
      {
        id: "strict-aliexpress",
        description: "AliExpress recommendation and affiliate parameters",
        mode: "strict",
        domains: ["aliexpress.com", "aliexpress.us"],
        params: [
          "algo_pvid",
          "algo_exp_id",
          "pdp_npi",
          "pdp_ext_f",
          "gatewayadapt",
          "aff_fcid",
          "aff_fsk",
          "aff_platform",
          "aff_trace_key"
        ],
        prefixes: ["aff_"]
      }
    ],
    protection: {
      description: "A URL matching any of these signals is never modified. Prefer leaving a tracker in place over breaking a login, payment or signed download.",
      domains: [
        "accounts.google.com",
        "pay.google.com",
        "payments.google.com",
        "login.microsoftonline.com",
        "login.microsoft.com",
        "login.live.com",
        "account.live.com",
        "appleid.apple.com",
        "idmsa.apple.com",
        "signin.aws.amazon.com",
        "auth0.com",
        "okta.com",
        "oktapreview.com",
        "onelogin.com",
        "duosecurity.com",
        "login.salesforce.com",
        "id.atlassian.com",
        "login.yahoo.com",
        "paypal.com",
        "checkout.stripe.com",
        "klarna.com",
        "adyen.com",
        "sofort.com",
        "giropay.de",
        "api.github.com"
      ],
      pathKeywords: [
        "oauth",
        "openid",
        "saml",
        "sso",
        "authorize",
        "authorization",
        "authenticate",
        "authentication",
        "auth",
        "callback",
        "login",
        "logon",
        "signin",
        "sign-in",
        "password",
        "passwort",
        "verify",
        "verification",
        "confirm",
        "confirmation",
        "activate",
        "activation",
        "invite",
        "invitation",
        "magic-link",
        "magiclink",
        "unsubscribe",
        "checkout",
        "payment",
        "3ds",
        "token",
        "otp",
        "mfa",
        "2fa",
        "consent",
        "api",
        "checkouts"
      ],
      pathSubstrings: [
        "password",
        "passwort",
        "resetpw",
        "unsubscribe",
        "optout",
        "opt-out",
        "preferencecenter",
        "verifyemail",
        "verify-email",
        "verifyaccount",
        "confirmemail",
        "confirm-email",
        "emailconfirm",
        "emailverif",
        "magiclink",
        "oauth",
        "saml",
        "preferences-center",
        "preference-center",
        "manage-preferences",
        "emailpreferences",
        "email-preferences",
        "subscription-center",
        "subscriptioncenter",
        "manage-subscription",
        "socialsession"
      ],
      params: [
        "sig",
        "signature",
        "hmac",
        "hash",
        "nonce",
        "ticket",
        "session",
        "sessionid",
        "session_id",
        "sid",
        "jsessionid",
        "phpsessid",
        "auth",
        "authkey",
        "apikey",
        "api_key",
        "key-pair-id",
        "otp",
        "password",
        "pwd",
        "passwd",
        "jwt",
        "assertion",
        "client_secret",
        "redirect_uri",
        "response_type",
        "relaystate",
        "sigalg",
        "hdnts",
        "hdntl",
        "auth_code",
        "authcode",
        "verification_code",
        "verify_code",
        "confirmation_code",
        "confirm_code",
        "invite_code",
        "invitation_code",
        "reset_code",
        "otp_code",
        "access_code",
        "activation_code",
        "login_code",
        "security_code",
        "login_hint",
        "id_token_hint",
        "domain_hint",
        "hdnea",
        "sesskey",
        "logouthash"
      ],
      paramPrefixes: ["x-amz-", "x-goog-", "oauth_", "openid.", "saml", "__cf_chl"],
      paramSuffixes: ["token", "signature"],
      paramCombinations: [
        ["code", "state"],
        ["code", "session_state"],
        ["expires", "s"],
        ["exp", "s"],
        ["expires", "h"],
        ["exp", "h"],
        ["ex", "hm"],
        ["oh", "oe"],
        ["len", "data"],
        ["st", "e"]
      ],
      experimentalParams: [
        "code",
        "error",
        "csrf",
        "_csrf",
        "xsrf",
        "_xsrf",
        "payment_intent",
        "payment_intent_client_secret",
        "setup_intent",
        "setup_intent_client_secret",
        "redirect_status",
        "paymentid",
        "payment_id",
        "payerid",
        "pares",
        "cres",
        "redirectresult",
        "expires",
        "key",
        "return_to",
        "returnto",
        "return_url",
        "returnurl",
        "redirect_url",
        "redirect_to",
        "callback_url",
        "tctokenurl",
        "wa",
        "wtrealm",
        "wctx",
        "wresult",
        "__token__",
        "rlkey",
        "resourcekey",
        "oobcode",
        "token_hash",
        "__clerk_ticket",
        "__clerk_status",
        "user_code",
        "device_code",
        "_wpnonce",
        "wmsauthsign",
        "auth_key",
        "trxid",
        "trxref",
        "shasign",
        "seal",
        "resourcepath",
        "merchantsig",
        "authorization",
        "redirect_flow_id",
        "amazoncheckoutsessionid",
        "orderkey",
        "mac2",
        "resultcode",
        "verify",
        "confirm",
        "invite",
        "inviteid"
      ]
    }
  };

  // ../../packages/core/src/rules.ts
  var EMPTY_PROTECTION = Object.freeze({
    domains: [],
    pathKeywords: [],
    pathSubstrings: [],
    params: [],
    paramPrefixes: [],
    paramSuffixes: [],
    paramCombinations: []
  });
  function rejectUnknownKeys(obj, allowed, where) {
    for (const key of Object.keys(obj)) {
      if (!allowed.includes(key)) throw new Error(`unknown field ${where}.${key}`);
    }
  }
  function isStringArray(value) {
    return Array.isArray(value) && value.every((v) => typeof v === "string");
  }
  function validateRuleSet(value) {
    if (typeof value !== "object" || value === null) throw new Error("rule set must be an object");
    const v = value;
    rejectUnknownKeys(v, ["schemaVersion", "rules", "protection"], "ruleSet");
    if (v.schemaVersion !== 1) throw new Error("unsupported schemaVersion");
    if (!Array.isArray(v.rules)) throw new Error("rules must be an array");
    const ids = /* @__PURE__ */ new Set();
    for (const r of v.rules) {
      if (typeof r !== "object" || r === null) throw new Error("rule must be an object");
      const rule = r;
      rejectUnknownKeys(rule, ["id", "description", "mode", "domains", "params", "prefixes"], "rule");
      if (typeof rule.id !== "string" || rule.id === "") throw new Error("rule.id must be a non-empty string");
      if (typeof rule.description !== "string") throw new Error(`${rule.id}.description must be a string`);
      if (ids.has(rule.id)) throw new Error(`duplicate rule id ${rule.id}`);
      ids.add(rule.id);
      if (rule.mode !== "clean" && rule.mode !== "strict") throw new Error(`invalid mode in ${rule.id}`);
      if (Array.isArray(rule.domains) && rule.domains.length === 0) {
        throw new Error(`${rule.id}.domains must not be empty (omit it for a global rule)`);
      }
      for (const key of ["domains", "params", "prefixes"]) {
        if (rule[key] !== void 0 && !isStringArray(rule[key])) {
          throw new Error(`${rule.id}.${key} must be a string array`);
        }
        if (isStringArray(rule[key]) && rule[key].some((s) => /[A-Z]/.test(s) || s === "")) {
          throw new Error(`${rule.id}.${key} entries must be non-empty lower-case strings`);
        }
      }
    }
    if (v.protection === void 0) v.protection = EMPTY_PROTECTION;
    const p = v.protection;
    if (typeof p !== "object" || p === null || Array.isArray(p)) throw new Error("protection must be an object");
    rejectUnknownKeys(
      p,
      [
        "description",
        "domains",
        "pathKeywords",
        "pathSubstrings",
        "params",
        "paramPrefixes",
        "paramSuffixes",
        "paramCombinations",
        "experimentalParams"
      ],
      "protection"
    );
    if (p.description !== void 0 && typeof p.description !== "string") {
      throw new Error("protection.description must be a string");
    }
    for (const key of [
      "domains",
      "pathKeywords",
      "pathSubstrings",
      "params",
      "paramPrefixes",
      "paramSuffixes"
    ]) {
      if (!isStringArray(p[key])) throw new Error(`protection.${key} must be a string array`);
    }
    if (p.experimentalParams !== void 0 && !isStringArray(p.experimentalParams)) {
      throw new Error("protection.experimentalParams must be a string array");
    }
    if (!Array.isArray(p.paramCombinations) || !p.paramCombinations.every(isStringArray)) {
      throw new Error("protection.paramCombinations must be an array of string arrays");
    }
    const lists = [
      ...["domains", "pathKeywords", "pathSubstrings", "params", "paramPrefixes", "paramSuffixes"].map(
        (k) => p[k]
      ),
      ...p.paramCombinations,
      p.experimentalParams ?? []
    ];
    for (const list of lists) {
      if (list.some((s) => s === "" || /[A-Z]/.test(s))) {
        throw new Error("protection entries must be non-empty lower-case strings");
      }
    }
    if (p.paramCombinations.some((c) => c.length === 0)) {
      throw new Error("protection.paramCombinations entries must not be empty");
    }
    return value;
  }
  var defaultRuleSet = validateRuleSet(rules_default);

  // ../../packages/core/src/engine.ts
  function escapeRegExp(s) {
    return s.replace(/[.*+?^${}()|[\]\\/-]/g, "\\$&");
  }
  function asciiLower(s) {
    return s.replace(/[A-Z]/g, (c) => String.fromCharCode(c.charCodeAt(0) + 32));
  }
  function percentDecodeOr(raw) {
    try {
      return decodeURIComponent(raw);
    } catch {
      return raw;
    }
  }
  function normaliseKey(rawKey) {
    const spaced = rawKey.replace(/\+/g, " ");
    return asciiLower(spaced.includes("%") ? percentDecodeOr(spaced) : spaced);
  }
  function domainMatches(host2, domain) {
    return host2 === domain || host2.length > domain.length && host2.endsWith("." + domain);
  }
  function normaliseException(entry) {
    let e = asciiLower(trimC0(entry));
    if (e.startsWith("*.")) e = e.slice(2);
    if (e === "") return "";
    let host2;
    try {
      host2 = new URL(e.includes("://") ? e : `http://${e}`).hostname;
    } catch {
      return "";
    }
    const h = stripTrailingDots(asciiLower(host2));
    return isSaneHost(h) ? h : "";
  }
  function isSaneHost(host2) {
    return /^(?:[a-z0-9_.-]+|\[[0-9a-f:.]+\])$/.test(host2);
  }
  function stripTrailingDots(host2) {
    let h = host2;
    while (h.endsWith(".")) h = h.slice(0, -1);
    return h;
  }
  function encodeTrailingWhitespace(url) {
    let end = url.length;
    while (end > 0 && url.charCodeAt(end - 1) <= 32) end--;
    if (end === url.length) return url;
    let tail = "";
    for (let i = end; i < url.length; i++) {
      tail += "%" + url.charCodeAt(i).toString(16).toUpperCase().padStart(2, "0");
    }
    return url.slice(0, end) + tail;
  }
  function trimC0(s) {
    let start = 0;
    let end = s.length;
    while (start < end && s.charCodeAt(start) <= 32) start++;
    while (end > start && s.charCodeAt(end - 1) <= 32) end--;
    return s.slice(start, end);
  }
  function rawKeyOf(segment) {
    const eq = segment.indexOf("=");
    return eq === -1 ? segment : segment.slice(0, eq);
  }
  function isParamShapedFragment(fragment) {
    return fragment.includes("=") && !fragment.includes("/") && !fragment.includes("?") && !fragment.startsWith(":~:");
  }
  function stripParts(input, prefix, query, fragment) {
    const segments = (query ?? "").split("&").filter((seg) => seg !== "");
    if (segments.length === 0) return { url: input, changed: false, status: "unchanged", removed: [] };
    const removed = segments.map((seg) => ({
      name: rawKeyOf(seg),
      location: "query",
      ruleId: EXPERIMENTAL_RULE_ID
    }));
    const url = encodeTrailingWhitespace(prefix + (fragment === void 0 ? "" : "#" + fragment));
    return { url, changed: url !== input, status: "cleaned", removed };
  }
  function splitRaw(trimmed) {
    const hashIdx = trimmed.indexOf("#");
    const fragmentStart = hashIdx === -1 ? trimmed.length : hashIdx;
    const qIdx = trimmed.indexOf("?");
    const queryStart = qIdx !== -1 && qIdx < fragmentStart ? qIdx : -1;
    return {
      prefix: trimmed.slice(0, queryStart === -1 ? fragmentStart : queryStart),
      query: queryStart === -1 ? void 0 : trimmed.slice(queryStart + 1, fragmentStart),
      fragment: hashIdx === -1 ? void 0 : trimmed.slice(hashIdx + 1)
    };
  }
  function valueIsUrl(segment) {
    const eq = segment.indexOf("=");
    if (eq === -1) return false;
    const v = asciiLower(segment.slice(eq + 1, eq + 1 + 14));
    return ["http://", "https://", "http%3a%2f%2f", "https%3a%2f%2f"].some((x) => v.startsWith(x));
  }
  var EXPERIMENTAL_RULE_ID = "experimental";
  var Cleaner = class {
    ruleSet;
    compiled;
    pathKeywordRes;
    protectedParams;
    experimentalParams;
    constructor(ruleSet = defaultRuleSet) {
      this.ruleSet = ruleSet;
      this.compiled = ruleSet.rules.map((rule) => ({
        rule,
        params: new Set(rule.params ?? []),
        prefixes: rule.prefixes ?? [],
        domains: rule.domains
      }));
      this.pathKeywordRes = ruleSet.protection.pathKeywords.map((kw) => ({
        kw,
        re: new RegExp(`(^|[/_.-])(${escapeRegExp(kw)})($|[/_.0-9-])`)
      }));
      this.protectedParams = new Set(ruleSet.protection.params);
      this.experimentalParams = new Set(ruleSet.protection.experimentalParams ?? []);
    }
    clean(input, options = {}) {
      const mode = options.mode ?? "clean";
      const unchanged = (status, reason2) => reason2 === void 0 ? { url: input, changed: false, status, removed: [] } : { url: input, changed: false, status, removed: [], reason: reason2 };
      if (typeof input !== "string") return unchanged("invalid");
      const trimmed = trimC0(input);
      if (/[\t\n\r]/.test(trimmed)) return unchanged("invalid");
      let parsed;
      try {
        parsed = new URL(trimmed);
      } catch {
        return unchanged("invalid");
      }
      if (parsed.protocol !== "http:" && parsed.protocol !== "https:") return unchanged("unsupported");
      if (!isSaneHost(asciiLower(parsed.hostname))) return unchanged("invalid");
      if (mode === "bypass") return unchanged("bypassed");
      const host2 = stripTrailingDots(asciiLower(parsed.hostname));
      for (const entry of options.exceptions ?? []) {
        const ex = normaliseException(entry);
        if (ex !== "" && domainMatches(host2, ex)) return unchanged("excepted");
      }
      const { prefix, query, fragment } = splitRaw(trimmed);
      const reason = this.protectionReason(host2, parsed.pathname, query, fragment, mode === "experimental");
      if (reason !== void 0) return unchanged("protected", reason);
      if (mode === "experimental") return stripParts(input, prefix, query, fragment);
      const applicable = this.compiled.filter(
        (c) => (c.rule.mode === "clean" || mode === "strict") && (c.domains === void 0 || c.domains.some((d) => domainMatches(host2, d)))
      );
      const removed = [];
      const cleanPart = (part, location) => part.split("&").filter((segment) => {
        const rawKey = rawKeyOf(segment);
        const key = normaliseKey(rawKey);
        const match = applicable.find((c) => c.params.has(key) || c.prefixes.some((p) => key.startsWith(p)));
        if (match === void 0) return true;
        removed.push({ name: rawKey, location, ruleId: match.rule.id });
        return false;
      }).join("&");
      const newQuery = query === void 0 ? void 0 : cleanPart(query, "query");
      const removedFromQuery = removed.length;
      const newFragment = fragment !== void 0 && mode === "strict" && isParamShapedFragment(fragment) ? cleanPart(fragment, "fragment") : fragment;
      const removedFromFragment = removed.length - removedFromQuery;
      if (removed.length === 0) return unchanged("unchanged");
      let url = prefix;
      if (newQuery !== void 0 && !(newQuery === "" && removedFromQuery > 0)) url += "?" + newQuery;
      if (newFragment !== void 0 && !(newFragment === "" && removedFromFragment > 0)) url += "#" + newFragment;
      url = encodeTrailingWhitespace(url);
      return { url, changed: url !== input, status: "cleaned", removed };
    }
    protectionReason(host2, pathname, query, fragment, experimental) {
      const p = this.ruleSet.protection;
      const domain = p.domains.find((d) => domainMatches(host2, d));
      if (domain !== void 0) return `domain:${domain}`;
      const path = asciiLower(percentDecodeOr(pathname));
      const kw = this.pathKeywordRes.find(({ re }) => re.test(path));
      if (kw !== void 0) return `path:${kw.kw}`;
      const sub = p.pathSubstrings.find((x) => path.includes(x));
      if (sub !== void 0) return `path:${sub}`;
      const keys = [];
      if (query !== void 0) for (const seg of query.split("&")) keys.push(normaliseKey(rawKeyOf(seg)));
      if (fragment !== void 0 && fragment.includes("=")) {
        for (const seg of fragment.split("&")) keys.push(normaliseKey(rawKeyOf(seg)));
      }
      for (const key of keys) {
        if (key === "") continue;
        if (this.protectedParams.has(key) || experimental && this.experimentalParams.has(key) || p.paramPrefixes.some((x) => key.startsWith(x)) || p.paramSuffixes.some((x) => key.endsWith(x))) {
          return `param:${key}`;
        }
      }
      const keySet = new Set(keys);
      const combo = p.paramCombinations.find((c) => c.every((k) => keySet.has(k)));
      if (combo !== void 0) return `combination:${combo.join("+")}`;
      if (experimental) {
        const segments = [...query?.split("&") ?? [], ...fragment?.includes("=") ? fragment.split("&") : []];
        if (segments.some(valueIsUrl)) return "value:url";
      }
      return void 0;
    }
  };
  var defaultCleaner = new Cleaner();
  function cleanUrl(input, options = {}) {
    return defaultCleaner.clean(input, options);
  }

  // ../../packages/core/src/dnr.ts
  function toAsciiDomain(entry) {
    const host2 = normaliseException(entry);
    if (host2 === "") return "";
    try {
      const u = new URL(`http://${host2}/`);
      if (u.hostname.startsWith("[")) return "";
      if (u.port !== "" || u.username !== "" || u.pathname !== "/" || asciiLower(u.hostname) !== u.hostname) return "";
      return host2;
    } catch {
      return "";
    }
  }

  // src/settings.ts
  var DEFAULT_SETTINGS = Object.freeze({
    enabled: true,
    mode: "clean",
    exceptions: [],
    pausedUntil: 0,
    copyCleaning: true
  });
  var MAX_EXCEPTIONS = 1e3;
  function sanitizeExceptions(entries) {
    const out = /* @__PURE__ */ new Set();
    for (const entry of entries) {
      if (typeof entry !== "string" || entry.length > 2048) continue;
      const domain = toAsciiDomain(entry);
      if (domain !== "" && domain.length <= 253) out.add(domain);
      if (out.size >= MAX_EXCEPTIONS) break;
    }
    return [...out].sort();
  }
  function sanitizeSettings(raw) {
    const r = typeof raw === "object" && raw !== null ? raw : {};
    const pausedUntil = typeof r.pausedUntil === "number" && Number.isFinite(r.pausedUntil) && r.pausedUntil > 0 ? r.pausedUntil : 0;
    return {
      enabled: typeof r.enabled === "boolean" ? r.enabled : DEFAULT_SETTINGS.enabled,
      mode: r.mode === "strict" || r.mode === "experimental" ? r.mode : "clean",
      exceptions: Array.isArray(r.exceptions) ? sanitizeExceptions(r.exceptions) : [],
      pausedUntil,
      copyCleaning: typeof r.copyCleaning === "boolean" ? r.copyCleaning : DEFAULT_SETTINGS.copyCleaning
    };
  }
  function effectiveMode(s, now = Date.now()) {
    if (!s.enabled || s.pausedUntil > now) return "bypass";
    return s.mode;
  }
  var SETTINGS_KEYS = Object.keys(DEFAULT_SETTINGS);
  async function loadSettings() {
    const stored = await chrome.storage.local.get(SETTINGS_KEYS);
    return sanitizeSettings({ ...DEFAULT_SETTINGS, ...stored });
  }
  async function saveSettings(patch) {
    const next = sanitizeSettings({ ...await loadSettings(), ...patch });
    const keys = Object.keys(patch).filter((k) => SETTINGS_KEYS.includes(k));
    await chrome.storage.local.set(Object.fromEntries(keys.map((k) => [k, next[k]])));
    return next;
  }

  // src/mode-controls.ts
  function byId(id) {
    const el = document.getElementById(id);
    if (el === null) throw new Error(`missing #${id}`);
    return el;
  }
  function asMode(value) {
    return value === "strict" || value === "experimental" ? value : "clean";
  }
  function setupModeControls() {
    const radios = [...document.querySelectorAll('input[name="mode"]')];
    const confirmBox = byId("exp-confirm");
    const enableBtn = byId("exp-enable");
    const cancelBtn = byId("exp-cancel");
    const activeBox = byId("exp-active");
    const backBtn = byId("exp-back");
    let current;
    const showRadios = (mode) => {
      for (const r of radios) r.checked = r.value === mode;
    };
    const closeConfirm = () => {
      confirmBox.hidden = true;
      if (current !== void 0) showRadios(current.mode);
    };
    for (const r of radios) {
      r.addEventListener("change", () => {
        if (!r.checked) return;
        const mode = asMode(r.value);
        if (mode === "experimental" && current?.mode !== "experimental") {
          confirmBox.hidden = false;
          cancelBtn.focus();
          return;
        }
        confirmBox.hidden = true;
        void saveSettings({ mode });
      });
    }
    enableBtn.addEventListener("click", () => {
      confirmBox.hidden = true;
      void saveSettings({ mode: "experimental" });
      radios.find((r) => r.value === "experimental")?.focus();
    });
    cancelBtn.addEventListener("click", () => {
      closeConfirm();
      radios.find((r) => r.checked)?.focus();
    });
    const cancelOnEscape = (e) => {
      if (e.key === "Escape" && !confirmBox.hidden) {
        e.preventDefault();
        cancelBtn.click();
      }
    };
    confirmBox.addEventListener("keydown", cancelOnEscape);
    for (const r of radios) r.addEventListener("keydown", cancelOnEscape);
    backBtn.addEventListener("click", () => {
      confirmBox.hidden = true;
      void saveSettings({ mode: "clean" });
      radios.find((r) => r.value === "clean")?.focus();
    });
    return {
      render(s) {
        current = s;
        if (confirmBox.hidden || s.mode === "experimental" || !s.enabled) {
          confirmBox.hidden = true;
          showRadios(s.mode);
        }
        for (const r of radios) r.disabled = !s.enabled;
        activeBox.hidden = !(s.enabled && s.mode === "experimental");
        enableBtn.disabled = !s.enabled;
      }
    };
  }

  // src/popup.ts
  var PAUSE_MINUTES = 15;
  function $(id) {
    const el = document.getElementById(id);
    if (el === null) throw new Error(`missing #${id}`);
    return el;
  }
  var enabledBox = $("enabled");
  var modeControls = setupModeControls();
  var pauseBtn = $("pause");
  var statusEl = $("status");
  var siteSection = $("site-section");
  var siteHost = $("site-host");
  var siteException = $("site-exception");
  var tabPausedBox = $("tab-paused");
  var copyBtn = $("copy");
  var copyResult = $("copy-result");
  var loopSection = $("loop-section");
  var loopHostEl = $("loop-host");
  var loopRetry = $("loop-retry");
  var siteNote = $("site-note");
  var tab;
  var host = "";
  function hostOf(url) {
    if (url === void 0) return "";
    try {
      const u = new URL(url);
      return u.protocol === "http:" || u.protocol === "https:" ? u.hostname.replace(/\.+$/, "") : "";
    } catch {
      return "";
    }
  }
  function coveringException(s) {
    return s.exceptions.find((d) => host === d || host.endsWith(`.${d}`));
  }
  function render(s) {
    const mode = effectiveMode(s);
    enabledBox.checked = s.enabled;
    modeControls.render(s);
    const paused = s.enabled && s.pausedUntil > Date.now();
    pauseBtn.textContent = paused ? "Resume now" : `Pause for ${PAUSE_MINUTES} minutes`;
    pauseBtn.disabled = !s.enabled;
    if (!s.enabled) statusEl.textContent = "Off";
    else if (paused)
      statusEl.textContent = `Paused until ${new Date(s.pausedUntil).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}`;
    else statusEl.textContent = mode === "strict" ? "Strict" : mode === "experimental" ? "Experimental" : "Active";
    statusEl.classList.toggle("off", mode === "bypass");
    siteSection.hidden = host === "";
    siteHost.textContent = host || "\u2013";
    const covering = coveringException(s);
    siteException.checked = covering !== void 0;
    const byParent = covering !== void 0 && covering !== host;
    siteException.disabled = byParent;
    siteNote.textContent = byParent ? `Covered by the exception for ${covering} (change it in Settings).` : "";
    copyBtn.disabled = tab?.url === void 0 || hostOf(tab.url) === "";
  }
  async function init() {
    [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    host = hostOf(tab?.url);
    render(await loadSettings());
    if (tab?.id !== void 0 && host !== "") {
      const state = await chrome.runtime.sendMessage({ type: "getTabState", tabId: tab.id });
      tabPausedBox.checked = state?.pausedByUser === true;
      if (state?.loopHost !== void 0 && state.loopHost === host) {
        loopHostEl.textContent = state.loopHost;
        if (state.loopNotOurs === true) {
          $("loop-text").textContent = "still fails with cleaning turned off for this site \u2013 the loop is probably not caused by Untrackable. If it involves another site, use \u201CPause in this tab\u201D and reload; otherwise try again later or contact the site.";
          loopRetry.hidden = true;
        }
        loopSection.hidden = false;
      }
    }
  }
  enabledBox.addEventListener("change", () => void saveSettings({ enabled: enabledBox.checked, pausedUntil: 0 }));
  pauseBtn.addEventListener("click", async () => {
    const s = await loadSettings();
    const paused = s.pausedUntil > Date.now();
    await saveSettings({ pausedUntil: paused ? 0 : Date.now() + PAUSE_MINUTES * 6e4 });
  });
  siteException.addEventListener("change", async () => {
    const s = await loadSettings();
    const exceptions = siteException.checked ? [...s.exceptions, host] : s.exceptions.filter((d) => d !== host);
    await saveSettings({ exceptions });
  });
  tabPausedBox.addEventListener("change", async () => {
    if (tab?.id === void 0) return;
    await chrome.runtime.sendMessage({ type: "setTabPaused", tabId: tab.id, paused: tabPausedBox.checked });
  });
  copyBtn.addEventListener("click", async () => {
    if (tab?.url === void 0 || tab.url.length > 32768) return;
    const s = await loadSettings();
    const result = cleanUrl(tab.url, { mode: s.mode, exceptions: s.exceptions });
    const ok = await chrome.runtime.sendMessage({ type: "copyText", text: result.url }) === true;
    copyResult.textContent = !ok ? "Copy failed" : result.removed.length > 0 ? `Copied \u2013 removed ${result.removed.length} ${s.mode === "experimental" ? "parameter" : "tracker"}${result.removed.length === 1 ? "" : "s"}` : "Copied";
  });
  loopRetry.addEventListener("click", async () => {
    if (tab?.id === void 0) return;
    loopRetry.disabled = true;
    const ok = await chrome.runtime.sendMessage({ type: "retryLoop", tabId: tab.id }) === true;
    if (ok) window.close();
    else if (loopHostEl.parentElement)
      loopHostEl.parentElement.textContent = "Not possible right now \u2013 at most one reload per minute.";
  });
  $("open-options").addEventListener("click", () => void chrome.runtime.openOptionsPage());
  chrome.storage.onChanged.addListener((_c, area) => {
    if (area === "local") void loadSettings().then(render);
  });
  void init();
})();
