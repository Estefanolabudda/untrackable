"use strict";
(() => {
  // src/offscreen.ts
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (sender.id !== chrome.runtime.id || sender.tab !== void 0 || sender.url !== chrome.runtime.getURL("background.js") || typeof message !== "object" || message === null) {
      return false;
    }
    const m = message;
    if (m.target !== "offscreen" || m.type !== "copy" || typeof m.text !== "string") return false;
    const area = document.createElement("textarea");
    area.value = m.text;
    document.body.append(area);
    area.select();
    let ok;
    try {
      ok = document.execCommand("copy");
    } catch {
      ok = false;
    } finally {
      area.remove();
    }
    sendResponse(ok);
    return false;
  });
})();
